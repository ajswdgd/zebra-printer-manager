import struct
import zlib
from pathlib import Path
w,h = 638,827
# Black frame and asymmetric bars make scaling/orientation visible.
pixels = b''.join(b'\0' + bytes(0 if x < 12 or x >= w-12 or y < 12 or y >= h-12 or (80 < x < 180 and 100 < y < 300) else 255 for x in range(w)) for y in range(h))
def chunk(kind, data):
    return struct.pack('!I',len(data)) + kind + data + struct.pack('!I',zlib.crc32(kind+data))
Path('/data/label.png').write_bytes(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR',struct.pack('!2I5B',w,h,8,0,0,0,0)) + chunk(b'IDAT',zlib.compress(pixels)) + chunk(b'IEND',b''))
