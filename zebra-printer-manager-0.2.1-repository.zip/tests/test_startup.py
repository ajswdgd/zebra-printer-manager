"""No real daemons: deterministic readiness budgets and early-exit failures."""
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lprint'))
from manager.startup import wait_for_dbus, wait_for_avahi, avahi_hostname


class Clock:
    def __init__(self): self.now = 0
    def monotonic(self): return self.now
    def sleep(self, seconds): self.now += seconds


class Readiness(unittest.TestCase):
    def setUp(self):
        self.process = Mock()
        self.process.poll.return_value = None
        self.clock = Clock()
        self.time_patch = patch('manager.startup.time', self.clock)
        self.time_patch.start()
        self.addCleanup(self.time_patch.stop)

    def test_socket_existence_is_not_used_as_bus_readiness(self):
        with patch('manager.startup.subprocess.run', return_value=Mock(returncode=0, stdout='names')) as run:
            wait_for_dbus(self.process)
        self.assertIn('org.freedesktop.DBus.ListNames', run.call_args.args[0])
        self.assertIn('--reply-timeout=1000', run.call_args.args[0])
        self.assertLessEqual(run.call_args.kwargs['timeout'], 2)

    def test_dbus_failure_has_a_wall_clock_budget(self):
        with patch('manager.startup.subprocess.run', return_value=Mock(returncode=1, stdout='')):
            with self.assertRaisesRegex(RuntimeError, 'Private D-Bus did not become ready'):
                wait_for_dbus(self.process, timeout=0.3)
        self.assertLessEqual(self.clock.now, 0.31)

    def test_avahi_only_accepts_running_state(self):
        replies = [Mock(returncode=0, stdout='int32 1'), Mock(returncode=0, stdout='int32 20'),
                   Mock(returncode=0, stdout='int32 2')]
        with patch('manager.startup.subprocess.run', side_effect=replies) as run:
            wait_for_avahi(self.process, self.process)
        self.assertEqual(run.call_count, 3)

    def test_child_exit_is_detected_before_calling_dbus(self):
        self.process.poll.return_value = 1
        with patch('manager.startup.subprocess.run') as run:
            with self.assertRaisesRegex(RuntimeError, 'Avahi exited during startup'):
                wait_for_avahi(self.process, self.process)
        run.assert_not_called()

    def test_dbus_dependency_exit_is_detected(self):
        dead = Mock(); dead.poll.return_value = 7
        with patch('manager.startup.subprocess.run') as run:
            with self.assertRaisesRegex(RuntimeError, 'Private D-Bus exited during startup'):
                wait_for_avahi(self.process, dead)
        run.assert_not_called()

    def test_hung_client_is_bounded_and_retried(self):
        with patch('manager.startup.subprocess.run', side_effect=subprocess.TimeoutExpired('fixture', 1)) as run:
            with self.assertRaisesRegex(RuntimeError, 'did not become ready'):
                wait_for_dbus(self.process, timeout=0.3)
        self.assertLessEqual(self.clock.now, 0.31)
        self.assertLessEqual(run.call_count, 4)

    def test_hostname_lookup_is_bounded_and_validated(self):
        with patch('manager.startup.subprocess.run', return_value=Mock(returncode=0, stdout='string "fixture.local"')) as run:
            self.assertEqual(avahi_hostname(self.process), 'fixture.local')
            self.assertEqual(run.call_args.kwargs['timeout'], 2)
        with patch('manager.startup.subprocess.run', return_value=Mock(returncode=0, stdout='malformed')):
            with self.assertRaisesRegex(RuntimeError, 'valid hostname'):
                avahi_hostname(self.process)
        with patch('manager.startup.subprocess.run', side_effect=subprocess.TimeoutExpired('fixture', 1)):
            with self.assertRaisesRegex(RuntimeError, 'timed out'):
                avahi_hostname(self.process)

    def test_missing_readiness_client_reports_an_explicit_error(self):
        with patch('manager.startup.subprocess.run', side_effect=FileNotFoundError):
            with self.assertRaisesRegex(RuntimeError, 'readiness client could not run'):
                wait_for_dbus(self.process)


if __name__ == '__main__': unittest.main()
