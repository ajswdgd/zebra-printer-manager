import socket
import subprocess

with socket.socket() as listener:
    listener.bind(('0.0.0.0',8631))
    listener.listen()
    result = subprocess.run(['python3','/run.py'], capture_output=True,text=True,timeout=10)
    assert result.returncode != 0
    assert 'Address already in use' in result.stderr
    print('PASS: occupied IPP port causes clear failure before services start')
