"""Browser acceptance against an isolated test adapter, not a live HA instance."""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
out=Path(os.environ.get('ZPM_BROWSER_RESULTS','/workspace/zpm-evidence/browser'));out.mkdir(parents=True,exist_ok=True)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1280,'height':1000})
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto('http://127.0.0.1:18100/api/hassio_ingress/test-token/')
    page.get_by_role('heading',name='Your printers').wait_for()
    page.get_by_role('heading',name='Second Zebra',exact=True).wait_for()
    assert page.locator('#printers article').count()==2
    page.screenshot(path=str(out/'desktop.png'),full_page=True)
    page.get_by_role('button',name='Add printer',exact=False).click()
    page.get_by_role('heading',name='Add printer').wait_for()
    page.get_by_label('Printer name',exact=True).fill('Browser Zebra')
    page.get_by_label('Address',exact=True).fill('127.0.0.1')
    page.get_by_label('Printer port',exact=True).fill('9199')
    page.get_by_role('button',name='Save printer').click()
    page.locator('#editor').wait_for(state='hidden',timeout=90000)
    page.get_by_role('heading',name='Browser Zebra',exact=True).wait_for()
    card=page.locator('article').filter(has=page.get_by_role('heading',name='Browser Zebra',exact=True))
    card.get_by_role('button',name='Edit',exact=True).click()
    page.get_by_label('Label length (mm)',exact=True).fill('75')
    page.get_by_role('button',name='Save printer').click()
    page.locator('#editor').wait_for(state='hidden',timeout=90000)
    page.on('dialog',lambda dialog:dialog.accept())
    card.get_by_role('button',name='Remove',exact=True).click()
    page.get_by_role('heading',name='Browser Zebra',exact=True).wait_for(state='hidden',timeout=90000)
    page.get_by_role('button',name='Show logs').click()
    page.locator('#logs').wait_for(state='visible')
    page.wait_for_function("() => document.querySelector('#logs').textContent.length > 0")
    with page.expect_download() as info:page.get_by_role('button',name='Download diagnostics').click()
    info.value.save_as(str(out/'diagnostics.json'))
    assert json.loads((out/'diagnostics.json').read_text())['state']['version']=='0.2.1'
    page.get_by_role('button',name='Hide logs').click()
    page.set_viewport_size({'width':390,'height':844})
    page.screenshot(path=str(out/'mobile.png'),full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    assert not errors,errors
    browser.close()
(out/'results.txt').write_text('PASS: Ingress-prefix assets/API, desktop/mobile layout, browser add/edit/remove, logs and diagnostic download; no JavaScript exceptions. Simulated proxy, not actual HA.\n')
print((out/'results.txt').read_text())
