"""Developer-only prefix-stripping Ingress adapter; never copied into production."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import http.client
PREFIX='/api/hassio_ingress/test-token'
class Proxy(BaseHTTPRequestHandler):
    def do(self):
        c=http.client.HTTPConnection('127.0.0.1',8099,timeout=90)
        data=self.rfile.read(int(self.headers.get('Content-Length','0')))
        path=self.path[len(PREFIX):] if self.path.startswith(PREFIX+'/') else self.path
        headers={k:v for k,v in self.headers.items() if k.lower() not in ('host','connection','x-ingress-path')}
        if self.path.startswith(PREFIX+'/'):headers['X-Ingress-Path']=PREFIX
        c.request(self.command,path,body=data,headers=headers)
        r=c.getresponse();body=r.read();self.send_response(r.status)
        for k,v in r.getheaders():
            if k.lower()!='connection':self.send_header(k,v)
        self.end_headers();self.wfile.write(body);c.close()
    do_GET=do_POST=do_PUT=do_DELETE=do
ThreadingHTTPServer(('0.0.0.0',8100),Proxy).serve_forever()
