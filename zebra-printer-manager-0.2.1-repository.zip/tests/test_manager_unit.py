import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lprint'))
from manager.model import printer, media, driver, load, atomic_json, UserError
from manager.discovery import parse_mdns, scan_hosts
from manager.label import png

class Validation(unittest.TestCase):
    def test_invalid_input_and_limits(self):
        p=printer({'name':'ZD411','address':'192.168.50.110'})
        self.assertEqual(media(p),'custom_54x70mm_54x70mm')
        self.assertEqual(driver(p),'zpl_2inch-300dpi-dt')
        for key,value in [('address','http://x'),('id','../attack'),('dpi',250),('sensing','wrong'),('width_mm',float('nan')),('height_mm',0),('port',True),('darkness',101)]:
            with self.subTest(key=key),self.assertRaises(UserError):printer({**p,key:value})
    def test_readonly_discovery_constraints(self):
        for subnet in ('0.0.0.0/0','192.168.0.0/16','8.8.8.8/32','::1/128'):
            with self.assertRaises(ValueError):scan_hosts(subnet)
        self.assertEqual(scan_hosts('192.168.50.110/32'),['192.168.50.110'])
        hints=parse_mdns('=;eth0;IPv4;Zebra\\032ZD411;_pdl-datastream._tcp;local;zebra.local;192.168.50.110;9100;"ty=Zebra ZD411"')
        self.assertEqual(hints[0]['port'],9100)
        self.assertFalse(hints[0]['verified'])
    def test_label_is_real_png_at_physical_resolution(self):
        p=printer({'name':'ZD411','address':'192.168.50.110'})
        content=png(p)
        self.assertEqual(content[:8],b'\x89PNG\r\n\x1a\n')
        self.assertEqual(struct.unpack('!II',content[16:24]),(638,827))
    def test_v010_migration_preserves_settings(self):
        with tempfile.TemporaryDirectory() as directory:
            d=Path(directory)
            d.joinpath('.lprint.conf').write_text('''<Printer driver="zpl_2inch-300dpi-dt" name="Zebra-ZD411" uri="socket://192.168.50.110:9100">
media-col-default width="5400" length="7000" tracking="mark"
printer-darkness-configured 61
</Printer>
''')
            config=load(d,{})
            self.assertEqual(config['printers'][0]['sensing'],'mark')
            self.assertEqual(config['printers'][0]['darkness'],61)
            self.assertTrue((d/'pre-manager-lprint.conf').exists())
            atomic_json(d/'manager.json',config)
            self.assertEqual(load(d,{}),config)

class AccessControl(unittest.TestCase):
    def test_rejects_non_ingress_peer_even_with_forged_headers(self):
        import os, threading, urllib.request, urllib.error
        from manager.web import Server
        previous=os.environ.pop('ZPM_TEST_MODE',None)
        server=Server(None,0)
        worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
        try:
            request=urllib.request.Request(f'http://127.0.0.1:{server.server_port}/api/state',headers={'X-Forwarded-For':'172.30.32.2','X-Ingress-Path':'/fake'})
            with self.assertRaises(urllib.error.HTTPError) as error:
                urllib.request.build_opener(urllib.request.ProxyHandler({})).open(request,timeout=2)
            self.assertEqual(error.exception.code,403)
        finally:
            server.shutdown();server.server_close();worker.join()
            if previous is not None:os.environ['ZPM_TEST_MODE']=previous

class StartupRecovery(unittest.TestCase):
    def test_startup_retry_is_bounded_and_recovers(self):
        from unittest.mock import Mock,patch
        from manager.runtime import Runtime
        runtime=Runtime.__new__(Runtime)
        runtime.port=8631;runtime.hostname='test.local';runtime.data=Path('/tmp');runtime.options={}
        runtime.children={};runtime.cli=Mock(return_value='')
        dead=Mock();dead.poll.return_value=1
        live=Mock();live.poll.return_value=None
        with patch('manager.runtime.Path') as path,patch('manager.runtime.time.sleep'):
            path.return_value.exists.return_value=True
            runtime.spawn=Mock(side_effect=[dead,live]);runtime.halt=Mock()
            runtime.start_lprint()
            self.assertEqual(runtime.spawn.call_count,2)
            runtime.spawn=Mock(return_value=dead)
            with self.assertRaises(RuntimeError):runtime.start_lprint()
            self.assertEqual(runtime.spawn.call_count,3)

if __name__=='__main__':unittest.main()
