"""Repository layout, source provenance, identity and architecture contracts."""
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from validate_repository import ROOT, validate


class AddonPackaging(unittest.TestCase):
    def test_real_tree_has_preserved_identity_and_arm64_support(self):
        result = validate(ROOT)
        self.assertEqual(result['version'], '0.2.1')
        self.assertIn('aarch64', result['architectures'])
        self.assertEqual(result['supervisor_install'], 'not tested')

    def test_source_and_frontend_are_required(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            shutil.copytree(ROOT / 'lprint', root / 'lprint')
            for name in ('repository.yaml', 'TESTING.md', 'PUBLISHING.md', 'LICENSE'):
                shutil.copyfile(ROOT / name, root / name)
            (root / 'lprint/manager/static/app.js').unlink()
            with self.assertRaisesRegex(AssertionError, 'Missing required'):
                validate(root)

    def test_identity_change_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            shutil.copytree(ROOT / 'lprint', root / 'lprint')
            shutil.copyfile(ROOT / 'repository.yaml', root / 'repository.yaml')
            config = root / 'lprint/config.yaml'
            config.write_text(config.read_text().replace('slug: lprint_zebra', 'slug: renamed'))
            with self.assertRaisesRegex(AssertionError, 'identity'):
                validate(root)

    def test_original_regression_suites_remain_present(self):
        for name in ('integration.py', 'manager_integration.py', 'migration_integration.py',
                     'test_manager_unit.py', 'browser_test.py', 'manager_checks.py',
                     'attributes.test', 'print-job.test', 'hold-job.test'):
            self.assertTrue((ROOT / 'tests' / name).is_file(), name)
