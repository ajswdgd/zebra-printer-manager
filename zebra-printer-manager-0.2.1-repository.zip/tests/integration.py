#!/usr/bin/env python3
"""Test the production image. Optional LPRINT_QEMU_PATH enables ARM64 emulation."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

image = sys.argv[1] if len(sys.argv) > 1 else 'ha-lprint:test'
root = Path(__file__).resolve().parent
name = 'ha-lprint-integration'
network = name + '-net'
qemu = os.environ.get('LPRINT_QEMU_PATH')
exec_prefix = ['/dev/.buildkit_qemu_emulator'] if qemu else []
data = Path(tempfile.mkdtemp(prefix='ha-lprint-'))
results = Path(os.environ.get('LPRINT_RESULTS',str(root/'results')))
results.mkdir(exist_ok=True)

def docker(*args, check=True):
    r = subprocess.run(['docker', *map(str,args)], check=check, text=True, capture_output=True)
    if check and r.stderr:
        print(r.stderr, end='')
    return r.stdout

def execute(*args):
    if qemu:
        args = (f'/usr/bin/{args[0]}', *args[1:])
    return docker('exec', name, *exec_prefix, *args)

def start():
    runargs = ['run','-d','--name',name,'--network',network,'-v',f'{data}:/data','-v',f'{root}:/tests:ro']
    if qemu:
        runargs += ['--platform','linux/arm64','-v',f'{qemu}:/dev/.buildkit_qemu_emulator:ro','--entrypoint','/dev/.buildkit_qemu_emulator',image,'/usr/bin/python3','/run.py']
    else:
        runargs += [image]
    docker(*runargs)
    for _ in range(120):
        logs = docker('logs',name)
        if 'LPrint ready' in logs:
            return
        if docker('inspect','--format','{{.State.Running}}',name).strip() != 'true':
            raise RuntimeError(logs)
        time.sleep(.25)
    raise RuntimeError('Startup timed out')

try:
    docker('network','create',network)
    (data/'options.json').write_text(json.dumps({'printer_ip':'127.0.0.1','printer_port':9100,'ipp_port':8631,'thermal_transfer':False,'log_level':'info'}))
    for fixture in (root/'fixtures').iterdir():
        shutil.copy(fixture,data/fixture.name)
    start()
    docker('exec','-d',name,*exec_prefix,'/usr/bin/python3','/tests/fixture.py')
    time.sleep(.5)
    for _ in range(3):
        result = execute('ipptool','-tv','ipp://localhost:8631/ipp/print/Zebra-ZD411','/tests/attributes.test')
    (results/'attributes.txt').write_text(result)
    for service in ('_ipp._tcp','_universal._sub._ipp._tcp'):
        address = docker('inspect','--format','{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}',name).strip()
        for _ in range(30):
            record = execute('avahi-browse','-rt',service)
            if 'Zebra-ZD411' in record and '8631' in record and 'image/urf' in record and address in record:
                break
            time.sleep(.5)
        else:
            raise AssertionError(f'Expected discovery address {address}: {record}')
        (results/f'{service}.txt').write_text(record)
    for ext in ('png','urf','pwg'):
        fmt = {'png':'image/png','urf':'image/urf','pwg':'image/pwg-raster'}[ext]
        execute('ipptool','-t','-f',f'/data/label.{ext}','-d',f'filetype={fmt}','ipp://localhost:8631/ipp/print/Zebra-ZD411','/tests/print-job.test')
    for _ in range(120):
        jobs = execute('lprint','jobs','-d','Zebra-ZD411')
        if jobs.count('completed') == 3:
            break
        time.sleep(.25)
    else:
        raise RuntimeError(jobs)
    (results/'jobs.txt').write_text(jobs)
    capture = (data/'zpl-capture.bin').read_bytes()
    assert capture.count(b'~DGR:') == 3 and capture.count(b'^XGR:') == 3
    assert b'^PW637' in capture and b'^MTD' in capture and b'^MNY' in capture
    (results/'capture.zpl').write_bytes(capture)
    execute('lprint','modify','-d','Zebra-ZD411','-o','printer-darkness-configured=61')
    docker('stop',name)
    docker('rm',name)
    assert 'printer-darkness-configured 61' in (data/'.lprint.conf').read_text()
    start()
    assert 'printer-darkness-configured 61' in (data/'.lprint.conf').read_text()
    for _ in range(3):
        execute('ipptool','-t','ipp://localhost:8631/ipp/print/Zebra-ZD411','/tests/attributes.test')
    attrs = execute('ipptool','-tv','ipp://localhost:8631/ipp/print/Zebra-ZD411','/tests/attributes.test')
    assert 'printer-darkness-configured (integer) = 61' in attrs
    print('PASS: repeated IPP queries, AirPrint subtype/TXT, PNG/URF/PWG to TCP ZPL, container replacement and darkness persistence')
finally:
    logs = docker('logs',name,check=False)
    (results/'server.log').write_text(logs)
    docker('rm','-f',name,check=False)
    # Container writes as root; ask Docker to remove its test data.
    cleanargs = ['run','--rm','-v',f'{data}:/cleanup']
    if qemu:
        cleanargs += ['--platform','linux/arm64','-v',f'{qemu}:/dev/.buildkit_qemu_emulator:ro','--entrypoint','/dev/.buildkit_qemu_emulator',image,'/bin/sh']
    else:
        cleanargs += ['--entrypoint','sh',image]
    docker(*cleanargs,'-c','rm -rf /cleanup/* /cleanup/.[!.]*',check=False)
    docker('network','rm',network,check=False)
    shutil.rmtree(data,ignore_errors=True)
