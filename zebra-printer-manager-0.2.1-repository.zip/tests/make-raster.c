/* Create actual Apple Raster and PWG Raster test jobs using libcups. */
#include <cups/raster.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(int argc, char **argv) {
  if (argc != 3) return 2;
  int fd = open(argv[1], O_WRONLY|O_CREAT|O_TRUNC, 0644);
  if (fd < 0) return 3;
  cups_raster_t *r = cupsRasterOpen(fd, !strcmp(argv[2], "urf") ? CUPS_RASTER_WRITE_APPLE : CUPS_RASTER_WRITE_PWG);
  cups_page_header2_t h;
  memset(&h, 0, sizeof(h));
  h.HWResolution[0] = h.HWResolution[1] = 300;
  h.cupsWidth = 638; h.cupsHeight = 827;
  h.cupsBitsPerColor = h.cupsBitsPerPixel = 8;
  h.cupsBytesPerLine = 638; h.cupsNumColors = 1;
  h.cupsColorSpace = CUPS_CSPACE_SW;
  h.cupsColorOrder = CUPS_ORDER_CHUNKED;
  h.PageSize[0] = 153; h.PageSize[1] = 198;
  h.cupsPageSize[0] = 54.0f * 72 / 25.4f;
  h.cupsPageSize[1] = 70.0f * 72 / 25.4f;
  h.NumCopies = 1;
  strcpy(h.cupsPageSizeName, "custom_54x70mm_54x70mm");
  if (!cupsRasterWriteHeader2(r, &h)) return 4;
  unsigned char row[638];
  for (unsigned y = 0; y < 827; y++) {
    for (unsigned x = 0; x < 638; x++)
      row[x] = (x < 12 || x >= 626 || y < 12 || y >= 815 || (80 < x && x < 180 && 100 < y && y < 300)) ? 0 : 255;
    if (cupsRasterWritePixels(r, row, sizeof(row)) != sizeof(row)) return 5;
  }
  cupsRasterClose(r); close(fd); return 0;
}
