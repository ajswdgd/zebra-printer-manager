"""TCP Zebra simulator. Captures bytes; responds to status only, no physical emulation."""
import socketserver
from pathlib import Path
import threading

class Zebra(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(120)
        while True:
            try:
                data = self.request.recv(65536)
            except TimeoutError:
                break
            if not data:
                break
            with open('/data/zpl-capture.bin', 'ab') as out:
                out.write(data)
            if b'getvar "device.product_name"' in data:
                self.request.sendall(b'"Zebra ZD411-300dpi ZPL"\r\n')
            if b'getvar "head.resolution.in_dpi"' in data:
                self.request.sendall(b'"300"\r\n')
            if b'~HQES' in data:
                self.request.sendall(b'\x02\nPRINTER STATUS\nERRORS: 0 00000000 00000000\nWARNINGS: 0 00000000 00000000\n\x03')
            if b'~HS' in data:
                self.request.sendall(b'\x02000,0,0,827,000,0,0,0,000,0,0,0\x03\r\n')

class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

Server(('0.0.0.0', 9100), Zebra).serve_forever()
