#!/usr/bin/env python3
"""Docker integration harness for the actual production manager API."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

image=sys.argv[1] if len(sys.argv)>1 else 'zebra-manager:amd64'
root=Path(__file__).resolve().parent
name='zebra-manager-integration';network=name+'-net'
data=Path(tempfile.mkdtemp(prefix='zebra-manager-'))
results=Path(os.environ.get('ZPM_RESULTS',str(root/'results-manager')));results.mkdir(parents=True,exist_ok=True)
qemu=os.environ.get('LPRINT_QEMU_PATH')
prefix=['/dev/.buildkit_qemu_emulator'] if qemu else []
def docker(*args,check=True):
    r=subprocess.run(['docker',*map(str,args)],capture_output=True,text=True)
    if check and r.returncode:raise RuntimeError(r.stdout+r.stderr)
    return r.stdout+r.stderr

def execute(*args):
    if qemu:args=(f'/usr/bin/{args[0]}',*args[1:])
    return docker('exec',name,*prefix,*args)

def start():
    args=['run','-d','--name',name,'--network',network,'-e','ZPM_TEST_MODE=1','-v',f'{data}:/data','-v',f'{root}:/tests:ro']
    if os.environ.get('ZPM_KEEP_TEST_CONTAINER'):args+=['-p','127.0.0.1:18100:8100']
    if qemu:args+=['--platform','linux/arm64','-v',f'{qemu}:/dev/.buildkit_qemu_emulator:ro','--entrypoint','/dev/.buildkit_qemu_emulator',image,'/usr/bin/python3','/run.py']
    else:args+=[image]
    docker(*args)
    for _ in range(240):
        logs=docker('logs',name)
        if 'Zebra Printer Manager ready' in logs:return
        if docker('inspect','--format','{{.State.Running}}',name).strip()!='true':raise RuntimeError(logs)
        time.sleep(.25)
    raise RuntimeError('Manager startup timeout\n'+logs[-5000:])
try:
    docker('network','create',network)
    (data/'options.json').write_text(json.dumps({'printer_ip':'127.0.0.1','ipp_port':8631,'printer_port':9100,'thermal_transfer':False,'log_level':'info'}))
    start()
    docker('exec','-d',name,*prefix,'/usr/bin/python3','/tests/fixture.py')
    time.sleep(.5)
    output=execute('python3','/tests/manager_checks.py')
    print(output,flush=True);(results/'api-checks.txt').write_text(output)
    before=json.loads((data/'manager.json').read_text())
    docker('stop',name);docker('rm',name);start()
    output=execute('python3','-c',"import json,urllib.request; r=json.load(urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:8099/api/state')); assert len(r['printers'])==2; p=next(p for p in r['printers'] if p['id']=='Zebra-Second'); assert p['dpi']==300 and p['width_mm']==50 and p['height_mm']==80 and p['darkness']==62; print('PASS: multiple printers and updated settings persist after container replacement')")
    print(output,flush=True)
    assert json.loads((data/'manager.json').read_text())==before
    for filename in ('manager.json','.lprint.conf','manager-checked.json','zpl-capture.bin'):
        shutil.copy(data/filename,results/filename.lstrip('.'))
    if os.environ.get('ZPM_KEEP_TEST_CONTAINER'):
        docker('exec','-d',name,*prefix,'/usr/bin/python3','/tests/fixture.py')
        docker('exec','-d',name,*prefix,'/usr/bin/python3','/tests/browser_proxy.py')
        (results/'test-data-path.txt').write_text(str(data))
        print('Browser test container left running on localhost:18100',flush=True)
finally:
    (results/'server.log').write_text(docker('logs',name,check=False))
    if not os.environ.get('ZPM_KEEP_TEST_CONTAINER'):
        docker('rm','-f',name,check=False);docker('network','rm',network,check=False)
