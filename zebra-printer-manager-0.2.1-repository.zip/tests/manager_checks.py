"""Executed inside the production test container through its Ingress test adapter."""
import json
from pathlib import Path
import subprocess
import time
import urllib.request
import urllib.error

ROOT='http://127.0.0.1:8099'
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def api(path,method='GET',body=None,expected=200,headers=True):
    hdr={'Content-Type':'application/json'}
    if headers:hdr['X-Zebra-Manager']='1'
    req=urllib.request.Request(ROOT+path,data=json.dumps(body or {}).encode() if method!='GET' else None,method=method,headers=hdr)
    try:
        response=opener.open(req,timeout=90)
    except urllib.error.HTTPError as error:response=error
    value=json.load(response)
    assert response.status==expected,(path,response.status,value)
    return value

def attributes(queue):
    return subprocess.run(['ipptool','-tv',f'ipp://127.0.0.1:8631/ipp/print/{queue}','/tests/all-attributes.test'],capture_output=True,text=True,check=True).stdout

def wait_jobs(queue):
    for _ in range(100):
        jobs=subprocess.run(['lprint','jobs','-d',queue],capture_output=True,text=True,check=True).stdout
        if 'completed' in jobs:return jobs
        time.sleep(.2)
    raise AssertionError(jobs)

state=api('/api/state');first=state['printers'][0]
assert first['id']=='Zebra-ZD411'
# Reject cross-origin/simple requests and malformed values before touching queues.
api('/api/refresh','POST',expected=403,headers=False)
api('/api/printers','POST',{'name':'Bad','address':'x; touch /tmp/oops'},expected=400)
api('/api/discover','POST',{'subnet':'0.0.0.0/0'},expected=400)
api('/api/refresh','POST')
assert api('/api/state')['printers'][0]['status']['reachable'] is True
# Read-only discovery on a single private test address, not the user's LAN.
import socket
address=socket.gethostbyname(socket.gethostname())
# Advertise a simulated physical Zebra through the live Avahi daemon.
publication=subprocess.Popen(['avahi-publish-service','Zebra ZD411 fixture','_pdl-datastream._tcp','9100','ty=Zebra ZD411','pdl=application/vnd.zebra-zpl'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
try:
    for _ in range(20):
        browse=subprocess.run(['avahi-browse','-prt','_pdl-datastream._tcp'],capture_output=True,text=True,check=True).stdout
        if 'Zebra' in browse and address in browse:break
        time.sleep(.2)
    api('/api/discover','POST',expected=202)
    for _ in range(80):
        found=api('/api/state')['discovery']
        if not found['running']:break
        time.sleep(.3)
    assert any(p['address']==address and p['verified'] for p in found['printers']),found
    print('PASS: automatic live Bonjour advertisement discovery plus Zebra identity confirmation')
finally:
    publication.terminate();publication.wait(timeout=5)
api('/api/discover','POST',{'subnet':address+'/32'},expected=202)
for _ in range(80):
    found=api('/api/state')['discovery']
    if not found['running']:break
    time.sleep(.3)
assert any(p['address']==address and p['verified'] for p in found['printers']),found
print('PASS: validation, request protection, monitoring and live read-only Zebra discovery')
# Add a second queue and verify actual IPP defaults, not just JSON settings.
p={'id':'Zebra-Second','name':'Second Zebra','address':address,'port':9100,'dpi':203,'width_mm':40,'height_mm':60,'sensing':'mark','thermal_transfer':False,'darkness':55}
api('/api/printers','POST',p)
attrs=attributes(p['id'])
for value in ('custom_40x60mm_40x60mm','203dpi','media-tracking=mark'):
    assert value in attrs,(value,attrs)
api('/api/printers','POST',p,expected=409)
api('/api/printers/Zebra-Second/test','POST',expected=202)
jobs=wait_jobs('Zebra-Second')
capture=Path('/data/zpl-capture.bin').read_bytes()
assert b'^MNM' in capture and b'^MTD' in capture
print('PASS: second printer, arbitrary label size, 203 DPI, black-mark sensing, PNG test job and captured ZPL')
# Update label dimensions/resolution and verify they reach LPrint.
p.update(dpi=300,width_mm=50,height_mm=80,sensing='gap',darkness=62)
api('/api/printers/Zebra-Second','PUT',p)
attrs=attributes(p['id'])
for value in ('custom_50x80mm_50x80mm','300dpi','media-tracking=gap'):
    assert value in attrs,(value,attrs)
assert 'printer-darkness-configured (integer) = 62' in attrs
# Verify a connection edit reaches LPrint's real serialized device URI.
changed={**p,'address':'127.0.0.1','port':9198}
api('/api/printers/Zebra-Second','PUT',changed)
header=next(line for line in Path('/data/.lprint.conf').read_text().splitlines() if line.startswith('<Printer ') and 'name="Zebra-Second"' in line)
assert 'uri="socket://127.0.0.1:9198"' in header,header
api('/api/printers/Zebra-Second','PUT',p)
print('PASS: address/port changes reach the actual LPrint transport')
# A held job must prevent disruptive configuration changes.
subprocess.run(['ipptool','-t','-f','/data/test-labels/Zebra-Second.png','ipp://127.0.0.1:8631/ipp/print/Zebra-Second','/tests/hold-job.test'],check=True,capture_output=True)
api('/api/printers/Zebra-Second','PUT',p,expected=409)
api('/api/printers/Zebra-Second/cancel','POST')
print('PASS: configuration is blocked while a held print job exists')
# Diagnostic output is bounded; raw label payload is not exported.
diag=api('/api/diagnostics')
assert len(diag['logs'])<=250 and diag['state']['version']=='0.2.1'
assert len(api('/api/state')['printers'])==2
# An unreachable printer gives a clear error and does not queue a test.
unreachable={**p,'id':'Zebra-Offline','name':'Offline Zebra','address':'127.0.0.1','port':9199}
api('/api/printers','POST',unreachable)
api('/api/refresh','POST')
info=next(p for p in api('/api/state')['printers'] if p['id']=='Zebra-Offline')
assert not info['status']['reachable'] and 'Cannot connect' in info['status']['error']
api('/api/printers/Zebra-Offline/test','POST',expected=409)
api('/api/printers/Zebra-Offline','DELETE')
assert len(api('/api/state')['printers'])==2
print('PASS: editing, DPI/dimension/sensing propagation, diagnostics, offline handling and removal')
Path('/data/manager-checked.json').write_text(json.dumps(api('/api/state')))
