#!/bin/sh
set -eu
# A second mDNS stack in the same network namespace, with a synthetic CUPS queue.
sed -i -e 's/host-name=lprint-zd411/host-name=lprint-peer/' -e 's/publish-addresses=no/publish-addresses=yes/' /etc/avahi/avahi-daemon.conf
dbus-uuidgen --ensure
mkdir -p /run/dbus
dbus-daemon --system --fork --nopidfile
avahi-daemon --no-chroot --daemonize
exec avahi-publish-service 'Existing CUPS test queue' _ipp._tcp 631 'rp=printers/existing' 'pdl=application/pdf'
