"""Production-container faults: a hung readiness client and an exited Avahi child."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from uuid import uuid4

image = sys.argv[1] if len(sys.argv) > 1 else 'zebra-manager:test'
results = Path(os.environ.get('ZPM_STARTUP_RESULTS', str(Path(__file__).parent / 'results-startup')))
results.mkdir(parents=True, exist_ok=True)
qemu = os.environ.get('LPRINT_QEMU_PATH')


def docker(*args, check=True):
    result = subprocess.run(['docker', *map(str, args)], capture_output=True, text=True)
    if check and result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout + result.stderr


for fault, executable, body, expected in (
    ('dbus-hang', '/usr/local/bin/dbus-send', '#!/bin/sh\nexec sleep 60\n', 'Private D-Bus did not become ready within 10s'),
    ('avahi-exit', '/usr/local/sbin/avahi-daemon', '#!/bin/sh\nexit 7\n', 'Avahi exited'),
):
    folder = Path(tempfile.mkdtemp(prefix='zebra-startup-fault-'))
    data = folder / 'data'
    data.mkdir()
    stub = folder / 'fault'
    stub.write_text(body)
    stub.chmod(0o755)
    (data / 'options.json').write_text(json.dumps({'printer_ip': '127.0.0.1', 'printer_port': 9100, 'ipp_port': 8631}))
    name = 'zebra-startup-fault-' + uuid4().hex[:10]
    started = time.monotonic()
    try:
        args = ['run', '-d', '--name', name, '-v', f'{data}:/data', '-v', f'{stub}:{executable}:ro']
        if qemu:
            args += ['--platform', 'linux/arm64', '-v', f'{qemu}:/dev/.buildkit_qemu_emulator:ro',
                     '--entrypoint', '/dev/.buildkit_qemu_emulator', image, '/usr/bin/python3', '/run.py']
        else:
            args += [image]
        docker(*args)
        for _ in range(100):
            running = docker('inspect', '--format', '{{.State.Running}}', name).strip()
            if running == 'false':
                break
            time.sleep(0.25)
        else:
            raise AssertionError(f'{fault}: container did not stop within budget')
        elapsed = time.monotonic() - started
        logs = docker('logs', name)
        (results / f'{fault}.log').write_text(logs)
        assert expected in logs, logs
        assert 'Zebra Printer Manager ready' not in logs and 'LPrint ready' not in logs
        assert docker('inspect', '--format', '{{.State.ExitCode}}', name).strip() == '1'
        assert elapsed < 25, elapsed
        print(f'PASS: {fault} failed closed in {elapsed:.2f}s with an explicit startup error; no healthy/print-ready claim')
    finally:
        docker('rm', '-f', name, check=False)
        args = ['run', '--rm', '-v', f'{folder}:/cleanup']
        if qemu:
            args += ['--platform', 'linux/arm64', '-v', f'{qemu}:/dev/.buildkit_qemu_emulator:ro',
                     '--entrypoint', '/dev/.buildkit_qemu_emulator', image, '/bin/sh']
        else:
            args += ['--entrypoint', 'sh', image]
        docker(*args, '-c', 'rm -rf /cleanup/data', check=False)
        stub.unlink(missing_ok=True)
        try:
            folder.rmdir()
        except OSError:
            pass
