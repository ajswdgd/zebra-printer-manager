"""Start the production image with state captured from the original v0.1 add-on."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
root=Path(__file__).resolve().parent
image=sys.argv[1] if len(sys.argv)>1 else 'zebra-manager:amd64'
data=Path(tempfile.mkdtemp(prefix='zpm-migration-'));name='zpm-migration'
results=Path(os.environ.get('ZPM_MIGRATION_RESULTS',str(root/'results-migration')));results.mkdir(parents=True,exist_ok=True)
def docker(*args,check=True):
    r=subprocess.run(['docker',*map(str,args)],capture_output=True,text=True)
    if check and r.returncode:raise RuntimeError(r.stdout+r.stderr)
    return r.stdout+r.stderr
try:
    source=(root/'fixtures/legacy-lprint.conf').read_text()
    (data/'.lprint.conf').write_text(source)
    (data/'options.json').write_text(json.dumps({'printer_ip':'192.168.50.110','ipp_port':8631,'printer_port':9100,'thermal_transfer':False,'log_level':'info'}))
    args=['run','-d','--name',name,'-v',f'{data}:/data','-e','ZPM_TEST_MODE=1']
    qemu=os.environ.get('LPRINT_QEMU_PATH')
    if qemu:
        args+=['--platform','linux/arm64','-v',f'{qemu}:/dev/.buildkit_qemu_emulator:ro',
               '--entrypoint','/dev/.buildkit_qemu_emulator',image,'/usr/bin/python3','/run.py']
    else:args+=[image]
    docker(*args)
    for _ in range(180):
        logs=docker('logs',name)
        if 'Zebra Printer Manager ready' in logs:break
        if docker('inspect','--format','{{.State.Running}}',name).strip()!='true':raise RuntimeError(logs)
        time.sleep(.25)
    else:raise RuntimeError(logs)
    migrated=json.loads((data/'manager.json').read_text())['printers'][0]
    assert migrated['id']=='Zebra-ZD411' and migrated['darkness']==61 and migrated['dpi']==300 and migrated['address']=='127.0.0.1'
    assert migrated['width_mm']==54 and migrated['height_mm']==70
    actual=(data/'.lprint.conf').read_text()
    for line in source.splitlines():
        if line.startswith('UUID ') or line.startswith('Job '):assert line in actual,line
    assert (data/'pre-manager-lprint.conf').read_text()==source
    (results/'manager.json').write_text(json.dumps(migrated,indent=2))
    print('PASS: real v0.1 state migration preserves queue name, address, 300 DPI, 54x70mm, darkness 61, system UUID and completed jobs; backup retained')
finally:
    (results/'server.log').write_text(docker('logs',name,check=False))
    docker('rm','-f',name,check=False)
