"""Create a small iPad-pasteable importer for a reviewed repository ZIP.

A narrowly scoped GitHub secret is necessary because importing .github/workflows
requires workflow-file write permission, which the default Actions token lacks.
No user runs a shell or copies application files into Home Assistant.
"""

import argparse
import hashlib
from pathlib import Path

TEMPLATE = r"""name: Import __TITLE__ source
on:
  workflow_dispatch:
permissions:
  contents: read
jobs:
  import:
    runs-on: ubuntu-24.04
    steps:
      - name: Require the publishing secret
        env:
          PUBLISH_TOKEN: ${{ secrets.REPOSITORY_PUBLISH_TOKEN }}
        run: |
          python3 - <<'PY'
          import os
          assert os.environ.get('PUBLISH_TOKEN'), 'Add REPOSITORY_PUBLISH_TOKEN in this repository Actions secrets. Never paste a token into a source file.'
          PY
      - uses: actions/checkout@v4
        with:
          token: ${{ secrets.REPOSITORY_PUBLISH_TOKEN }}
          ref: ${{ github.event.repository.default_branch }}
      - name: Verify and unpack this exact reviewed archive
        env:
          EXPECTED_REPOSITORY: __REPOSITORY__
          SOURCE_ARCHIVE: __ARCHIVE__
          SOURCE_SHA256: __SHA256__
          APP_MARKER: __MARKER__
          IS_PRIVATE: ${{ github.event.repository.private }}
        run: |
          python3 - <<'PY'
          import hashlib, json, os, pathlib, stat, zipfile
          root = pathlib.Path.cwd().resolve()
          assert os.environ['GITHUB_REPOSITORY'] == os.environ['EXPECTED_REPOSITORY'], 'This importer is for the named ajswdgd repository only'
          assert os.environ['IS_PRIVATE'] == 'false', 'Create a public repository'
          assert not (root / os.environ['APP_MARKER']).exists(), 'Existing application source detected. Do not replay an older snapshot over an installed repository; use normal validation and release workflows.'
          source = root / os.environ['SOURCE_ARCHIVE']
          assert source.is_file(), 'Upload the supplied repository ZIP unchanged to this repository root first'
          assert hashlib.sha256(source.read_bytes()).hexdigest() == os.environ['SOURCE_SHA256'], 'ZIP checksum mismatch; use the matching ZIP/importer pair'
          with zipfile.ZipFile(source) as archive:
              assert archive.testzip() is None
              assert sum(i.file_size for i in archive.infolist()) <= 50 * 1024 * 1024, 'Uncompressed archive too large'
              names = set()
              for item in archive.infolist():
                  path = pathlib.PurePosixPath(item.filename)
                  assert not path.is_absolute() and '..' not in path.parts and chr(92) not in item.filename
                  assert not {'.git', '.venv', 'node_modules', '__pycache__'}.intersection(path.parts)
                  assert item.filename not in names, 'Duplicate path'
                  assert item.filename != '.github/workflows/setup-publication.yml', 'Importer cannot overwrite itself'
                  assert not stat.S_ISLNK(item.external_attr >> 16), 'No symlink members'
                  destination = (root / path).resolve()
                  assert destination.is_relative_to(root), 'Existing symlink would escape repository'
                  names.add(item.filename)
              archive.extractall(root)
              for item in archive.infolist():
                  if not item.is_dir():
                      (root / item.filename).chmod(0o755 if (item.external_attr >> 16) & 0o111 else 0o644)
          assert (root / os.environ['APP_MARKER']).is_file(), 'Wrong repository layout'
          (root / 'IMPORT-PROVENANCE.json').write_text(json.dumps({
              'source_archive': source.name, 'sha256': os.environ['SOURCE_SHA256'],
              'repository': os.environ['EXPECTED_REPOSITORY'],
              'github_validation': 'check the subsequent workflow runs; not certified by import'}, indent=2) + '\n')
          source.unlink()
          PY
      - name: Commit source and retained tests
        env:
          PUBLISH_BRANCH: ${{ github.event.repository.default_branch }}
        run: |
          git config user.name 'github-actions[bot]'
          git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
          git add -A
          git commit -m 'Import reviewed __TITLE__ repository source'
          git push origin "HEAD:$PUBLISH_BRANCH"
      - name: Next step
        run: |
          printf '%s\n' 'Source imported. Open Actions and wait for the new validation workflows to pass. Import success alone does not certify Home Assistant installation.' >> "$GITHUB_STEP_SUMMARY"
"""


def create(archive, repository, title, marker, output):
    assert repository in ("ajswdgd/amcrest-camera-manager", "ajswdgd/zebra-printer-manager")
    assert archive.is_file()
    text = TEMPLATE
    replacements = {
        "__TITLE__": title,
        "__REPOSITORY__": repository,
        "__ARCHIVE__": archive.name,
        "__SHA256__": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "__MARKER__": marker,
    }
    for key, value in replacements.items():
        text = text.replace(key, value)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(text)
    return text


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--marker", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    create(args.archive, args.repository, args.title, args.marker, args.output)
    print(f"Browser importer prepared: {args.output}; actual GitHub execution remains untested.")
