"""Offline add-on distribution checks; not a running Supervisor install test."""
import ast
import hashlib
from pathlib import Path
import re
import tarfile

import yaml

ROOT = Path(__file__).resolve().parents[1]
SOURCE_SHA256 = 'f28c21bdd55e211ace6f908d938edb59d1ae6d3ef53b7485650779dcb0cb1d4a'
REPOSITORY = 'https://github.com/ajswdgd/zebra-printer-manager'


def validate(root):
    repository = yaml.safe_load((root / 'repository.yaml').read_text())
    config = yaml.safe_load((root / 'lprint/config.yaml').read_text())
    assert repository['url'] == REPOSITORY and repository['maintainer'] == 'ajswdgd'
    assert config['url'] == REPOSITORY
    assert config['slug'] == 'lprint_zebra', 'Installed add-on identity must not change'
    assert config['arch'] == ['aarch64', 'amd64']
    assert config['ingress'] is True and config['ingress_port'] == 0
    assert config['host_network'] is True and config['panel_admin'] is True
    assert config['hassio_api'] is True and config['hassio_role'] == 'default'
    assert config['init'] is False and config['boot'] == 'auto'
    assert config['stage'] == 'experimental'
    assert set(config['options']) == set(config['schema'])
    assert config['schema']['printer_port'] == config['schema']['ipp_port'] == 'port'
    assert 'ZPM_TEST_MODE' not in str(config), 'No test bypass in production manifest'
    version = config['version']
    assert re.fullmatch(r'\d+\.\d+\.\d+', version)
    constants = ast.parse((root / 'lprint/manager/__init__.py').read_text())
    actual = next(ast.literal_eval(node.value) for node in constants.body if isinstance(node, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == '__version__' for t in node.targets))
    assert actual == version
    assert f'Version {version}' in (root / 'lprint/manager/static/index.html').read_text()
    for name in ('lprint/Dockerfile', 'lprint/run.py', 'lprint/avahi-daemon.conf',
                 'lprint/DOCS.md', 'lprint/CHANGELOG.md', 'lprint/translations/en.yaml',
                 'lprint/manager/startup.py', 'lprint/manager/static/app.js',
                 'lprint/manager/static/style.css', 'lprint/source/LICENSE-LPRINT',
                 'lprint/source/NOTICE-LPRINT', 'TESTING.md', 'PUBLISHING.md', 'LICENSE'):
        assert (root / name).is_file(), f'Missing required source/documentation: {name}'
    source = root / 'lprint/source/lprint-1.3.1.tar.gz'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == SOURCE_SHA256
    with tarfile.open(source) as archive:
        assert any(Path(member.name).name == 'lprint.c' for member in archive.getmembers())
    dockerfile = (root / 'lprint/Dockerfile').read_text()
    assert 'FROM debian:trixie-slim' in dockerfile
    assert 'COPY source/lprint-1.3.1.tar.gz' in dockerfile
    assert 'COPY manager /manager' in dockerfile
    assert 'ENTRYPOINT ["python3", "/run.py"]' in dockerfile
    assert 'image' not in config, 'This repository uses native Supervisor source builds'
    for path in (root / 'lprint').rglob('*.py'):
        ast.parse(path.read_text(), filename=str(path))
    return {'version': version, 'repository': REPOSITORY, 'slug': config['slug'],
            'architectures': config['arch'], 'source_sha256': SOURCE_SHA256,
            'offline_packaging': 'passed', 'supervisor_install': 'not tested',
            'physical_printer_ipad': 'not tested'}


if __name__ == '__main__':
    import json
    print(json.dumps(validate(ROOT), indent=2))
