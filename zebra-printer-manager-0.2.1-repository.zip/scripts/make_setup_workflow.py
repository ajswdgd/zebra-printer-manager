"""Create a browser-pasteable GitHub workflow for this exact source snapshot."""
import base64
import hashlib
import io
from pathlib import Path
import tempfile
import zipfile
import yaml

root=Path(__file__).resolve().parents[1]
files=[]
for path in root.rglob('*'):
    if not path.is_file():continue
    parts=path.relative_to(root).parts
    if parts[0] not in {'lprint','tests','scripts'} and path.name not in {'README.md','PUBLISHING.md','TESTING.md','TESTING-0.1.0.md','LICENSE','repository.yaml','.gitignore'}:continue
    if any(x=='__pycache__' or x.startswith('results') for x in parts) or path.suffix=='.pyc':continue
    if path.name=='lprint-1.3.1.tar.gz':continue
    files.append(path)
stream=io.BytesIO()
with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(files):
        info=zipfile.ZipInfo(path.relative_to(root).as_posix(),date_time=(2026,10,27,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        bundle.writestr(info,path.read_bytes())
payload=stream.getvalue()
workflow='''name: Set up Zebra Printer Manager
on:
  workflow_dispatch:
permissions:
  contents: write
jobs:
  prepare:
    runs-on: ubuntu-24.04
    outputs:
      commit: ${{ steps.snapshot.outputs.commit }}
    steps:
      - uses: actions/checkout@v4
      - name: Unpack the delivered snapshot
        env:
          ZPM_SNAPSHOT: "__PAYLOAD__"
        run: |
          python3 - <<'PY'
          import base64, hashlib, io, os, pathlib, zipfile
          payload=base64.b64decode(os.environ['ZPM_SNAPSHOT'],validate=True)
          assert hashlib.sha256(payload).hexdigest() == '__SNAPSHOT_SHA256__'
          with zipfile.ZipFile(io.BytesIO(payload)) as archive:
              for item in archive.infolist():
                  path=pathlib.PurePosixPath(item.filename)
                  assert not path.is_absolute() and '..' not in path.parts
              archive.extractall('.')
          PY
      - name: Obtain the pinned released LPrint source
        run: |
          git clone --depth 1 --branch v1.3.1 https://github.com/michaelrsweet/lprint.git "$RUNNER_TEMP/lprint-source"
          test "$(git -C "$RUNNER_TEMP/lprint-source" rev-parse HEAD)" = "a34bfb9e41af200dc48b4714ba8c720770c17531"
          git -C "$RUNNER_TEMP/lprint-source" archive --format=tar.gz --prefix=lprint/ -o "$GITHUB_WORKSPACE/lprint/source/lprint-1.3.1.tar.gz" a34bfb9e41af200dc48b4714ba8c720770c17531
          python3 - <<'PY'
          import hashlib, pathlib
          assert hashlib.sha256(pathlib.Path('lprint/source/lprint-1.3.1.tar.gz').read_bytes()).hexdigest() == 'f28c21bdd55e211ace6f908d938edb59d1ae6d3ef53b7485650779dcb0cb1d4a'
          PY
      - name: Commit the app to this repository
        id: snapshot
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
          git add README.md PUBLISHING.md TESTING.md TESTING-0.1.0.md LICENSE repository.yaml .gitignore lprint tests scripts
          if ! git diff --cached --quiet; then
            git commit -m "Install Zebra Printer Manager 0.2.0 snapshot"
            git push origin "HEAD:$GITHUB_REF_NAME"
          fi
          echo "commit=$(git rev-parse HEAD)" >> "$GITHUB_OUTPUT"
  test:
    needs: prepare
    permissions:
      contents: read
    strategy:
      matrix:
        runner: [ubuntu-24.04, ubuntu-24.04-arm]
    runs-on: ${{ matrix.runner }}
    steps:
      - uses: actions/checkout@v4
        with:
          ref: ${{ needs.prepare.outputs.commit }}
      - run: docker build -t zebra-manager:test lprint
      - run: python3 -m unittest discover -s tests -p 'test_manager_unit.py' -v
      - run: python3 tests/integration.py zebra-manager:test
      - run: python3 tests/manager_integration.py zebra-manager:test
      - run: python3 tests/migration_integration.py zebra-manager:test
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: zebra-results-${{ matrix.runner }}
          path: tests/results*
'''
workflow=workflow.replace('__PAYLOAD__',base64.b64encode(payload).decode()).replace('__SNAPSHOT_SHA256__',hashlib.sha256(payload).hexdigest())
parsed=yaml.safe_load(workflow)
assert parsed['permissions']['contents']=='write'
assert parsed['jobs']['test']['needs']=='prepare'
assert len(workflow.encode())<240000
with tempfile.TemporaryDirectory() as directory:
    with zipfile.ZipFile(io.BytesIO(payload)) as bundle:bundle.extractall(directory)
    for path in files:
        assert (Path(directory)/path.relative_to(root)).read_bytes()==path.read_bytes()
(root/'SETUP-WORKFLOW.txt').write_text(workflow)
print(f'PASS: setup workflow YAML, safe snapshot paths and {len(files)} extracted source files match; {len(workflow.encode())} bytes. GitHub execution NOT tested.')
