"""Build the full reviewed source repository; exclude environments and live test data."""
import hashlib
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {'.git', '.venv', '__pycache__', 'node_modules', '.pytest_cache'}


def build(root, target, archive):
    files = [p for p in root.iterdir() if p.is_file() and
             (p.suffix in ('.md', '.yaml') or p.name in ('.gitignore', 'LICENSE', 'SETUP-WORKFLOW-0.2.0.txt'))]
    for directory in ('lprint', 'tests', 'scripts', '.github', 'evidence', 'evidence-0.2.0', 'evidence-0.2.1'):
        if not (root / directory).exists():
            continue
        files.extend(p for p in (root / directory).rglob('*') if p.is_file()
                     and not EXCLUDED.intersection(p.parts)
                     and not any(part.startswith('results') for part in p.relative_to(root).parts)
                     and p.suffix != '.pyc')
    files = sorted(set(files))
    checksums = '\n'.join(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root).as_posix()}' for path in files) + '\n'
    (root / 'SHA256SUMS').write_text(checksums)
    files.append(root / 'SHA256SUMS')
    archive.parent.mkdir(parents=True, exist_ok=True)
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as output:
        for path in files:
            relative = path.relative_to(root)
            destination = target / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            info = zipfile.ZipInfo(relative.as_posix(), (2026, 10, 27, 0, 0, 0))
            info.external_attr = (0o100755 if path.suffix == '.sh' else 0o100644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            output.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        assert set(check.namelist()) == {p.relative_to(root).as_posix() for p in files}
        for name in check.namelist():
            assert check.read(name) == (target / name).read_bytes()
    archive.with_suffix('.zip.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
    return len(files)


if __name__ == '__main__':
    archive = ROOT.parent / 'dist/zebra-printer-manager-0.2.1-repository.zip'
    count = build(ROOT, ROOT.parent / 'repositories/zebra-printer-manager', archive)
    print(f'Exported {count} reviewed files to {archive}')
