# Zebra Printer Manager for Home Assistant

Manage network Zebra ZPL printers and AirPrint inside Home Assistant. This is
version **0.2.1 of the existing LPrint Zebra AirPrint add-on**, not a replacement
printing stack. The add-on slug remains `lprint_zebra`.

Open the app in Home Assistant to find a printer or enter its IP, configure label
size and sensing, view connection/status information, submit a test label, and add
more printers. LPrint continues to receive Apple/PWG Raster and PNG over IPP and
produce ZPL over TCP. No CUPS administration, SSH, `/addons` access, external print
server or separate computer is required for installation or daily use.

**Status: a software-tested candidate, not a hardware-verified product.** See
[VALIDATION-0.2.1.md](VALIDATION-0.2.1.md) for current validation and [TESTING.md](TESTING.md) for the retained baseline tests and the remaining Home Assistant
Green / HAOS 18.3 / Zebra / iPad / IDEXX Neo acceptance tests.

## Install or update

The target public repository is **https://github.com/ajswdgd/zebra-printer-manager**.
It is prepared locally and **has not been published from this workspace** because
GitHub authentication is invalid. [PUBLISHING.md](PUBLISHING.md) and
[IPAD-PUBLISHING.md](IPAD-PUBLISHING.md) describe a browser-only import of the supplied
ZIP, including its workflows and tests. Wait for successful native AMD64/ARM64 CI
before using the target URL in Home Assistant. Do not add an empty repository or
upload this ZIP into HA; a GitHub workflow unpacks it first.

1. In Home Assistant, open **Settings → Apps → App Store → ⋮ → Repositories**
   (older UI: **Settings → Add-ons → Add-on Store**).
2. Add `https://github.com/ajswdgd/zebra-printer-manager` once published and validated. Select **Zebra Printer Manager → Install**.
   The Green builds its native ARM64 container. Allow several minutes and Internet
   access to Docker Hub / Debian repositories for the first build.
3. Start it. Enable **Start on boot** and **Show in sidebar**.
4. Select **Open Web UI**, or **Zebra Printers** in the sidebar. The initial
   Zebra ZD411 entry uses `192.168.50.110:9100`, 300 DPI, 54 × 70 mm, gap sensing
   and direct thermal. Edit it if needed, or choose a discovered printer.
5. Press **Print test label** once. Inspect the physical result before repeating.
6. On an iPad on the same LAN, open the source app's standard **Print** action,
   choose the configured **AirPrint name** (initially **Zebra-ZD411**), and print
   one correctly sized label.

If 0.1.0 is already installed, publish the update to the **same repository URL and
branch**, retain `lprint/` and the existing slug, make a Home Assistant backup,
then use **Update** on the app page. Settings migrate automatically; the original
LPrint state is also copied to `/data/pre-manager-lprint.conf`. Keeping the same
repository identity is essential: changing GitHub repositories creates a different
Home Assistant app instance and does not transfer its `/data` automatically.

## Management experience

- **Find printers:** Bonjour discovery runs when the page opens. Where a Zebra
  advertises a compatible service, its name/address appears as a candidate.
  A read-only Zebra SGD identity query confirms responding devices. Bonjour hints
  that cannot be confirmed are clearly labelled; they are not auto-added.
- **Scan subnet:** optional, explicit read-only scanning of one private IPv4
  subnet, `/24` or smaller (at most 256 addresses). Example `192.168.50.0/24`.
  Many Zebra configurations do not advertise Bonjour, so manual IP remains a
  normal supported path. Discovery never sends a print job or changes settings.
- **Configure:** address/port, physical DPI, label width/feed length, gap or
  black-mark sensing, continuous media, direct thermal or ribbon, and darkness.
  The initial ZD411 is a 300 DPI printer; choosing a different DPI does not change
  its physical printhead. Use dimensions supported by the actual hardware.
- **Status:** TCP reachable/unreachable is separate from the last LPrint-reported
  idle/printing/stopped state and fault reasons. It is refreshed about every
  15 seconds, or on demand. TCP reachability alone is not proof of readiness or
  a successful printed label.
- **Test label:** a real PNG diagnostic page is submitted through LPrint's queue.
  The UI reports submission, not physical completion. It includes a border,
  dimensions, DPI and a 10 mm square where the label is large enough.
- **Multiple printers:** up to 16 managed queues, each with a stable AirPrint name
  and separate settings. An exact duplicate address/port or AirPrint name is
  rejected. DNS aliases for one physical device still need operator care.
- **Diagnostics:** clear API/form errors, recent logs and a JSON download in the
  app. Persistent logs rotate at 750 kB with two backups. Diagnostic exports can
  contain LAN addresses and queue/job names; they do not contain label images.

When jobs are queued, **Cancel queued jobs** is available on the printer card.
Check whether a label already printed before cancelling or resubmitting.

Changing queues pauses LPrint briefly and reloads its state. Changes are refused
while managed queues have active or held jobs; failures restore the previous
LPrint state. Do not update the add-on while printing. Ordinary restarts do not
reinitialize working queues or clear their completed history.

## Home Assistant access and security

The manager uses **Ingress** and Home Assistant authentication, with an admin
sidebar panel. Its listener accepts only the Supervisor's actual TCP source
`172.30.32.2`; caller-supplied forwarding headers are not used as authentication.
The Supervisor chooses a free management port (`ingress_port: 0`), obtained through
the add-on's own information endpoint. No extra management port needs opening.
A developer-only environment flag allows loopback tests; it is not a user option
and is not enabled by the Home Assistant manifest.

AirPrint is a separate LAN service on TCP **8631**, as in 0.1.0. It must remain
reachable by iPads and is not carried by Ingress. The native LPrint web pages are
disabled; manage the printers in Home Assistant. Normal IPP printing remains
available to trusted LAN clients. Keep IPP off the public Internet.

Host networking is retained for multicast. The add-on runs container-local D-Bus
and Avahi, uses shared mDNS UDP 5353, publishes its A record **without a reverse
PTR**, and does not mount the host's D-Bus or replace its mDNS daemon. It does not
run cupsd, bind TCP 631 or open an inbound raw-print listener. TCP 9100 is outbound
to each Zebra. TCP 8631 conflicts cause an explicit startup failure. Other print
services may stay running; disable a duplicate AirPrint queue for the *same*
Zebra during acceptance testing to avoid selecting the wrong queue.

The host IPv4 address advertised by the app is selected using the route to the
first printer. IPv4 and a multicast-capable LAN are required. Multiple VLANs,
multiple host interfaces, guest-Wi-Fi isolation and actual HAOS service coexistence
still need on-site verification. The app does not configure your router or act
as an mDNS reflector.

## Persistent configuration and upgrading

`/data/manager.json` is the versioned configuration. `/data/.lprint.conf` and
`/data/spool` retain LPrint's queues, UUIDs, job state and files. Custom media are
prepared under `/data/media` before the driver builds its IPP attributes.
All remain in the add-on's persistent data across restarts and updates. Include
this app in Home Assistant backups; uninstalling with data removal discards them.

At first upgrade, the manager imports the existing Zebra socket queues, resolution,
media dimensions/sensing and darkness from the original LPrint state. The old
single-printer options are used only when initializing a new installation.
Afterwards edit printers in **Open Web UI**, not in add-on YAML or raw LPrint files.
Advanced global options remain in the Configuration tab:

```yaml
printer_ip: 192.168.50.110  # initial setup only
printer_port: 9100         # initial setup only
ipp_port: 8631             # restart after changing
thermal_transfer: false   # initial setup only
log_level: info            # restart after changing
```

Queue IDs/AirPrint names are immutable after creation to preserve their identity;
edit the friendly name freely. Removing a queue removes its LPrint job history.
The initial printer's expected printable area is approximately 54 × 70 mm; nominal
300 DPI corresponds to about 638 × 827 dots. Driver margins/rounding produce
`^PW637` in the original raster regression capture. Physical pitch, 300 versus
304.8 DPI, orientation and calibration must be checked on the actual roll.
Gap/web emits `^MNY`, black mark `^MNM`; continuous stock uses an explicit length.
Calibrate the Zebra's sensor using its normal controls when changing rolls.

## iPad and IDEXX Neo

LPrint advertises Apple Raster (`image/urf`), PWG Raster and PNG/JPEG, and the
AirPrint universal subtype. The existing released LPrint/PAPPL stack is retained
with the successful raster regression tests. It does not directly accept PDF;
the iOS print system must render the application's document into an advertised
raster format.

**IDEXX Neo has not been exercised.** Use its actual iPad/browser print flow with
one real 54 × 70 mm label. Verify that it offers Apple's Print interface, selects
the intended queue, uses the correct page dimensions and does not crop, rotate
or scale the content unexpectedly. This manager cannot force a web application
to offer printing or repair its document layout. Capturing Apple Raster in a
simulator is not proof that Neo's complete workflow is compatible.

## HACS investigation

HACS distributes custom integrations and frontend resources; it does not install
this print-server add-on. A separate HACS integration could provide entities or
automations later, but would require both it and the server. Those entities are
not needed for this management app, so **no HACS installation or custom integration
is required or shipped**. One Store app with Ingress is the practical route here.

Sources: [Home Assistant Ingress](https://contributors.home-assistant.io/apps/guides/ingress/),
[app configuration](https://contributors.home-assistant.io/apps/reference/configuration/),
[HACS app limitations](https://www.hacs.xyz/docs/faq/addons/).

## Development

The repository includes native AMD64/ARM64 CI jobs and repeatable tests; see
[TESTING.md](TESTING.md). LPrint is pinned to release 1.3.1. Existing corrections
for 2-inch selection, gap sensing, repeated IPP language attributes and fresh-queue
advertising are retained. Added media/queue handling is described in
[lprint/source/README.md](lprint/source/README.md).

This is an independent project, not an official Home Assistant, Zebra, Apple or
IDEXX product. Wrapper/manager: MIT. LPrint source: Apache-2.0, with original
LICENSE and NOTICE retained.
