> Historical v0.2.0 evidence from the uploaded project, preserved. Current startup patch and validation: [VALIDATION-0.2.1.md](VALIDATION-0.2.1.md). The old embedded setup snapshot is now named SETUP-WORKFLOW-0.2.0.txt; do not use it to publish 0.2.1.

# Zebra Printer Manager 0.2.0 validation — 2026-10-27

## Supported conclusion

The existing LPrint add-on was extended in place. The manager and the retained
printing path passed software tests on AMD64 and ARM64 **under emulation**. This
is a candidate for physical acceptance, not a claim of a fully operational Home
Assistant / iPad / Zebra / IDEXX Neo installation.

There was no connection to the user's printer at 192.168.50.110, no Home Assistant
instance in the test environment and no iPad. A private route/VPN to that LAN was
not available. GitHub publishing and Store installation were not performed.

## Environment and scope

- Docker Engine 28.4.0 on Linux x86_64; Debian trixie-slim images.
- Released LPrint 1.3.1 from the same vendored archive as 0.1.0, PAPPL 1.3.1,
  libcups 2.4.10; Debian package/security revisions are build-time dependent.
- ARM64 C build and runtime used BuildKit's QEMU ARM64 emulator. Runtime child
  processes were executed through the mounted `/dev/.buildkit_qemu_emulator`.
  This is test machinery only; native Home Assistant Green needs no emulator,
  privileged containers or compiler installed on the host.
- Separate Docker bridge networks isolate regression and manager test instances.
  DNS-SD assertions require the correct container address and port, not just a
  matching printer name.
- A threaded TCP 9100 Zebra simulator replies to `~HQES`, `~HS` and read-only SGD
  identity/resolution requests and captures the bytes. It does not interpret ZPL,
  render a label, exercise real firmware or emulate every fault response.
- UI browser tests use Chromium and a test-only proxy implementing Ingress-style
  prefix stripping. That proxy and the loopback test flag are absent/disabled in
  the production Home Assistant manifest. This is not an actual Supervisor login
  test or Safari/iPad test.

Tested local production image IDs are recorded in `evidence-0.2.0/images.txt`.
These are local image IDs, not published registry digests. The GitHub workflows
are supplied but have not run in GitHub during this session.

## Results

| Function | Evidence/result |
| --- | --- |
| AMD64 and ARM64 container builds | PASS; original released LPrint build extended with a bounded managed-media hook |
| ARM64 startup and subprocess execution | PASS under emulation: Python manager, LPrint, private D-Bus, Avahi and A-record publisher |
| Original PNG/Apple Raster/PWG Raster tests | PASS on both final architectures, unchanged print submissions over TCP IPP; three completed jobs and captured ZPL graphics |
| Original media and resolution | PASS, 300 DPI, 54 × 70 mm supported/default/ready, positive printer ID, repeated strict IPP requests |
| AirPrint advertisements | PASS, `_ipp._tcp` and `_universal._sub._ipp._tcp`, actual instance IP, port 8631, raster formats and URF RS300 |
| Automatic printer discovery | PASS with a live synthetic `_pdl-datastream._tcp` Zebra advertisement and read-only identity confirmation through the actual Avahi/API path; parser unit check also passed |
| Optional subnet scan | PASS on a single private Docker address with SGD responder; public or oversized networks rejected. User's LAN was not scanned |
| Manual add / multiple printers | PASS, second managed queue created through HTTP API and exercised through actual LPrint |
| DPI and arbitrary stock changes | PASS, 203 DPI / 40 × 60 mm, then 300 DPI / 50 × 80 mm; actual IPP attributes verified, not just stored JSON |
| Gap and black-mark sensing | PASS, actual default/ready IPP collections and captured ZPL (`^MNY` / `^MNM`) |
| Address/port editing | PASS, actual stopped/reloaded LPrint device URI verified after change, then restored |
| Connectivity and status | PASS, reachable simulator and deliberately closed port; IPP queue status available separately from TCP reachability |
| Test-label button API | PASS, generated physical-size PNG submitted through LPrint; job completed and ZPL captured. This proves software delivery only |
| Held/queued job protection | PASS, a real held IPP job causes settings changes to return 409; manager's cancel API clears it |
| Duplicate/invalid settings | PASS, duplicate queue, invalid address, invalid DPI/ranges, unsafe IDs and oversized/public scans rejected |
| Persistence | PASS on both architectures, container stopped/removed/replaced with same `/data`; both printers and changed DPI/dimensions/darkness preserved |
| Migration from 0.1.0 | PASS using real state captured from the original software-tested add-on: same queue, URI, 300 DPI, 54 × 70 mm, darkness 61, system UUID and completed jobs retained; original-state backup created |
| Manager access restriction | PASS, direct non-Ingress loopback requests denied even with forged forwarded-IP/Ingress headers; simple mutation requests without the custom JSON header denied |
| Browser UI | PASS, Ingress-prefix assets/API, add/edit/remove, diagnostics/logs/download; desktop 1280 × 1000 and phone 390 × 844 layouts; no JavaScript exceptions, no horizontal overflow |
| Manifest and CI configuration | YAML/schema consistency, unchanged slug, ARM64 support, Ingress, dynamic management port and admin panel verified statically. Real Supervisor validation/install remains outstanding |
| Publishing helper | Embedded archive path/hash/extraction and exact source archive generation checked locally. Actual GitHub execution/permissions and resulting public URL remain outstanding |

Six focused `unittest` checks cover settings validation, discovery constraints
and parsing, real PNG dimensions, original-state migration/atomic JSON, and the
Ingress source-address restriction and bounded startup recovery. Browser screenshots show simulated queues,
not a real user's printer.

The final evidence files in the delivered ZIP under `evidence-0.2.0/` include build/runtime logs, both
raster regression results and captures, both manager API results, migration,
unit/browser results, screenshots and image IDs. `TESTING-0.1.0.md` and the old
`evidence/` directory are retained as historical baseline evidence; do not confuse
their checks with new hardware verification. Evidence folders are omitted by the
lightweight browser publishing helper; they remain in the delivered ZIP.

## Problems caught during implementation

- Updating only media defaults was insufficient: LPrint's ready-media setter could
  overwrite the sensing choice. The manager now sets both real IPP collections.
- A media name must be present before PAPPL builds its supported attributes.
  A bounded driver callback hook loads manager stock settings before that point.
- PAPPL 1.3.1's modify CLI accepts but does not apply driver/transport changes.
  These two serialized queue fields are updated only while LPrint is stopped;
  the queue is reloaded, preserving identity/history. Resolution defaults are set
  explicitly to match the new driver. Failure paths restore the previous state.
- Browser test waits needed to account for asynchronous log loading and the app's
  Content Security Policy; the test waits for the loaded text without disabling
  CSP. The app keeps its restrictive policy.

One additional ARM64 emulator run hit an assertion in Avahi's D-Bus client glue
while LPrint was starting. LPrint startup now retries at most three times and logs
each failed attempt; a focused test verifies recovery and the retry limit. This is
recovery, not a proof that the upstream race cannot occur. Real HAOS stability and
long-running fault recovery remain acceptance items. Runtime service exits after
startup still stop the app with an error rather than silently claiming health.

The original fixes for 2-inch driver selection, gap mapping, duplicate language
attributes and fresh-queue registration remain. Their source notes are in
`lprint/source/README.md`.

## Remaining physical and external tests

1. **Home Assistant Green / HAOS 18.3:** Store repository addition, actual native
   build/install, same-repository update from 0.1.0, Ingress login/source address,
   dynamic port retrieval via Supervisor, sidebar, AppArmor/network behavior,
   resource use, boot, backup and backup restore. The API is designed for
   Supervisor's documented `172.30.32.2` source but that actual connection has not
   been observed here.
2. **Real discovery/network:** the Zebra's actual Bonjour advertisements and SGD
   strings; multicast on the user's Wi-Fi/VLAN, actual local subnet scanning,
   route/interface selection, DHCP changes and coexistence with the real HAOS,
   CUPS/Bonjour/systemd-resolved stack. The inherited A-only advertisement design
   avoids the reverse-PTR conflict found in 0.1.0 tests; this is not proof for
   every existing service. Confirm physical printers use ZPL, not just a Zebra
   model name. Unconfirmed hints require manual verification.
3. **Zebra ZD411:** reachability and real status/firmware at 192.168.50.110:9100,
   correct print mode, calibration, usable print width, label/gap pitch, measured
   300 versus 304.8 DPI scale, orientation, darkness, speed, clipping and barcode
   readability. The simulator cannot prove the printer accepts or correctly
   renders the captured ZPL.
4. **iPads / IDEXX Neo:** discovery in Apple's actual Print dialog, negotiated
   formats, source-app document rendering, Neo's actual browser/app Print action,
   page size, scaling, orientation, copies and barcode/text output. No Neo account,
   patient data or iPad was used. Direct PDF submission is not supported by LPrint;
   iOS must render the document into its advertised raster format.
5. **Faults and durability:** real media out, cover open, label jams, printer power
   cycles, connection interruption during a job, queue cancellation while physically
   printing, duplicate-print risks, sudden host power loss, and queued-job recovery.
   Persistence tests use graceful container replacement, not power-failure testing.
6. **Other hardware/settings:** physical additional printers, 600 DPI/ribbon mode,
   wide 4-inch heads and continuous-stock output were not separately print-tested.
   The configuration exposes existing generic LPrint capabilities; the tests
   exercised 203/300 DPI, direct thermal and gap/black-mark stock. Do not select
   hardware options the printer lacks. The manager supports 16 queues by design;
   the integration tests exercise two, not a 16-printer load benchmark.
7. **External publication:** GitHub account/org permissions, actual setup/CI workflow
   execution, public hosting URL and Home Assistant's Store cloning/installing it.
   No repository was published or tests run on GitHub in this session.

## Acceptance procedure entirely through UI

1. Publish through the browser route in PUBLISHING.md. Add its repository URL in
   Home Assistant's Store, Install/Start, enable Start on boot and Show in sidebar.
   For an existing installation, back it up and update from the same repository.
2. Open Zebra Printers. Check migrated/default address, 300 DPI, 54 × 70 mm and
   gap sensing. Try discovery; use manual IP if the Zebra does not advertise.
3. Refresh status. Submit **one** test label. Inspect dimensions, border, 10 mm
   reference square (if it fits), orientation, gap feed and readable text.
4. In the actual IDEXX Neo iPad workflow, print **one** correctly sized label to
   Zebra-ZD411. Check page size, scaling and barcode/text readability. Verify other
   unrelated printers remain discoverable.
5. Change a benign setting, restart the app through Home Assistant, and verify
   persistence and rediscovery. Reboot Home Assistant through its UI and repeat
   one label. Exercise backup/restore before relying on it operationally.
6. With expendable stock, test printer disconnect/reconnect, media out and queue
   cancellation. Inspect whether a label already printed before resubmitting.

Only after those checks pass should the user's installation be described as
fully operational.

## Reproduce software checks (developer Docker runner only)

End users do not run these on Home Assistant.

```sh
docker build -t zebra-manager:test lprint
python3 -m unittest discover -s tests -p 'test_manager_unit.py' -v
python3 tests/integration.py zebra-manager:test
python3 tests/manager_integration.py zebra-manager:test
python3 tests/migration_integration.py zebra-manager:test
```

The supplied GitHub workflow runs those on native AMD64 and ARM64 runners when
published. It has not executed in this session. Test-only browser setup is in
`tests/browser_proxy.py` and `tests/browser_test.py`; the actual production image
is used with fixtures mounted read-only. Chromium/Playwright are development
requirements only, not image or Home Assistant dependencies.

On this x86 runner, builds used BuildKit's bundled ARM64 emulator and the runtime
suites used `LPRINT_QEMU_PATH=/absolute/path/to/buildkit-qemu-aarch64`. The same
suites use native execution on a Green or native ARM64 CI runner.
