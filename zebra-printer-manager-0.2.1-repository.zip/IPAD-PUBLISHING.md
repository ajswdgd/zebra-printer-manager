# Publish both ajswdgd repositories from your iPad

These are two separate repositories, prepared from the existing source and tests:

| Repository | Home Assistant installation method | Runtime version |
|---|---|---|
| `https://github.com/ajswdgd/amcrest-camera-manager` | HACS custom **Integration** | 0.2.0 |
| `https://github.com/ajswdgd/zebra-printer-manager` | Add-on/App Store repository | 0.2.1 startup patch |

**Current status:** source and packaging are prepared locally. The configured GitHub CLI authentication is invalid even with network access enabled. Neither repository has been created/uploaded/published by this workspace. The following workflow is a browser-only alternative; it has not executed in your GitHub account. No SSH, Terminal add-on, Linux commands, source-tree upload, or file copying into Home Assistant is required.

## 1. Create both public repositories

In Safari, sign in to GitHub as **ajswdgd**, then use **New repository** for each name in the table. Choose **Public** and initialize with a README, using `main` as default branch. Do not add application code yet. In the Amcrest repository About panel, add a short description and topics `home-assistant`, `hacs`, `amcrest`, `onvif`, `security`. Leave Issues enabled. HACS checks those actual GitHub settings; local manifest fields alone cannot set them.

## 2. Authorize the one-time source import

The import includes retained GitHub workflow files. GitHub's default Actions token does not have permission to create/change workflow files, so this browser-only importer requires a narrowly scoped publishing token once.

In GitHub **Settings → Developer settings → Personal access tokens → Fine-grained tokens**, create a short-lived token:

- Resource owner: **ajswdgd**.
- Repository access: **Only select repositories**, selecting these two repositories.
- Repository permissions: **Contents: Read and write**, **Workflows: Read and write**. Metadata read access is automatic. No account-wide or administration permissions are needed.

Copy the value directly into each repository's **Settings → Secrets and variables → Actions → New repository secret**, named **REPOSITORY_PUBLISH_TOKEN**. Never put it into chat, a workflow/source file, a ZIP or a Home Assistant setting. The importer references only the secret name and does not print its value. This is a one-time publishing step, not a runtime dependency.

If your account/repository policy disallows this token or write operation, stop at the failed GitHub step and use an authorized GitHub connection for assisted publication. Do not weaken HA authentication or use SSH as a workaround. See [GitHub token permissions](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens).

## 3. Import each ZIP through GitHub Actions

For **Amcrest**, download these matching files from the delivery:

- `amcrest-camera-manager-hacs-repository.zip`
- `setup-amcrest-publication.yml.txt`

For **Zebra**:

- `zebra-printer-manager-0.2.1-repository.zip`
- `setup-zebra-publication.yml.txt`

Repeat the following in the corresponding GitHub repository:

1. **Add file → Upload files**: select the single repository ZIP from the iPad Files picker and commit it at the repository root. Keep the filename exactly as supplied. You do not need to extract it on your iPad.
2. **Add file → Create new file**: name it `.github/workflows/setup-publication.yml`.
3. Open the matching small `.yml.txt` delivery file, select/copy its text, and paste it into GitHub's editor. Review it and commit through the website. This is one setup file; none of the application source files need manual copying. Safari's **Request Desktop Website** can help if GitHub hides controls on a small screen.
4. Open **Actions → Import Amcrest Camera Manager source** or **Import Zebra Printer Manager source**, then **Run workflow**.
5. The workflow verifies the exact ZIP SHA256, expected `ajswdgd` repository and public visibility, checks safe paths, and refuses to overwrite existing application code. It unpacks source/tests/docs/workflows, records `IMPORT-PROVENANCE.json`, removes the staging ZIP from the current tree, commits the source and pushes to `main`.
6. The publishing token allows that push to install the retained workflow files and trigger their CI. Wait for the **new source validation workflows** to finish. A green import job only proves the import; it does not certify installation. Fix any reported validation failure before installing.

The importer never runs application startup against your clinic cameras/printer, never submits a physical print job, and never triggers an Abode alarm. Container tests use isolated simulators. Do not replay an older import snapshot over a repository containing application code; use normal reviewed updates instead. Initial import is guarded against this mistake.

## 4. Complete project-specific publication

### Amcrest

Wait for **Validate repository** (retained tests, packaging, HACS and Hassfest) to pass. Then run **Prepare release (iPad)** with version **0.2.0** and maintainer **ajswdgd**. This creates a **draft** only after checks pass. Open Releases, review it, then tap **Publish release**. Published stable releases are required; a tag, draft, ZIP attachment or default branch alone is not offered by this HACS setup.

Install/update through [the iPad HACS guide](https://github.com/ajswdgd/amcrest-camera-manager/blob/main/docs/ipad-installation.md). The generated [repository links](https://github.com/ajswdgd/amcrest-camera-manager/blob/main/docs/github-links.md) now use the real target name, but are usable only after publication. Existing config entries must be retained.

### Zebra

Wait for **Build and integration test** on both native AMD64 and ARM64 runners. It validates the manifests, builds the real LPrint image, runs all unit tests and the retained print/API/migration regressions. ARM64 runner availability must be enabled for the public repository. The add-on repository serves reviewed `main` source; there is no required GHCR image publication step. Supervisor builds its native ARM64 image automatically when Install is tapped.

After CI succeeds, use Home Assistant **Settings → Add-ons → Add-on Store → ⋮ → Repositories** (newer label: Apps/App Store), add the Zebra URL above, select **Zebra Printer Manager → Install → Start → Open Web UI**. Enable Start on boot and Show in sidebar. This is not a HACS integration.

For later Zebra versions, retain the same repository URL/branch, `lprint/` directory and **slug `lprint_zebra`**, back up from HA's UI, and use its add-on **Update** button. A new repository identity does not automatically transfer `/data` from a previous local or differently hosted add-on. Do not claim that cross-repository migration is implemented. See the Zebra PUBLISHING.md and physical acceptance plan.

After successful source import, delete the `REPOSITORY_PUBLISH_TOKEN` secrets and revoke the short-lived token if it is no longer needed. Normal validation and Amcrest draft releases use GitHub's own workflow token. Everyday HA installation and updates never require a GitHub publishing token.

## Validation boundaries

No actual GitHub Actions run, live HACS validation, Supervisor Store installation, native Green test, Safari/iPad test, printer output, IDEXX Neo printing or camera/Abode hardware test is claimed by these instructions. Use the supplied validation reports to distinguish checks executed here from required external acceptance. GitHub workflows can reveal repository-policy or future upstream requirements not visible offline.
