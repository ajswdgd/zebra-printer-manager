# Validation record — 2026-10-26

## Conclusion

LPrint is technically suitable for this bridge. The final add-on image passed
software integration tests on AMD64 and on ARM64 under emulation. This establishes
startup, the IPP/raster/ZPL path and simulated discovery; it does **not** establish
successful operation on the actual Home Assistant Green/iPad/Zebra installation.

The repository is prepared for Supervisor local builds from a GitHub repository.
It was not published to GitHub or installed by a real Supervisor in this session.

## Tested environment

- Linux x86_64 managed cloud environment, Docker Engine 28.4.0.
- Debian trixie-slim, LPrint **1.3.1** from vendored release source.
- PAPPL **1.3.1-2.1+b2**, libcups **2.4.10-3+deb13u2**.
- ARM64 image built using Docker Buildx/BuildKit 0.33.1 and its bundled ARM64 QEMU
  emulator. Initial standard binfmt-based attempts failed with `exec format
  error`; the subsequent BuildKit-emulated build succeeded with TLS verification
  and the environment's required proxy/CA trust intact.
- ARM64 runtime used BuildKit's emulator mounted at
  `/dev/.buildkit_qemu_emulator`, including its child-process emulation. This is
  a **test environment mechanism only**; native ARM64 Home Assistant Green needs
  no emulator or extra privileges.
- Separate Docker bridge networks isolated the final native and ARM64 integration
  runs from other test printers. Test discovery assertions check the actual
  container's advertised IPv4 address, not just a matching service name.
- Zebra simulator listened on TCP 9100, replied to `~HQES`/`~HS`, and captured
  output. Its synthetic status responses report ready media and no faults. It
  does not interpret or render ZPL and cannot validate physical printer behavior.

Tested production image IDs (local images, not published registry digests):

```text
linux/arm64 sha256:50c975ce80552b9ac2de8970d7721dfa0fbd2ab26331a8f491ac1b9c34373b18
linux/amd64 sha256:c9b10ed8468c7495a2a261082ed1766ec216ec51e1c3d4904ba8f83000f228f1
```

## Results

| Check | Result and scope |
| --- | --- |
| ARM64 container build | PASS, built ARM64 dependencies and LPrint C sources under BuildKit emulation |
| ARM64 executable and process startup | PASS, Python reports `aarch64`; LPrint, D-Bus, Avahi, publisher and child CLI processes start |
| Fresh data directory | PASS, creates queue automatically, internally restarts LPrint after provisioning, exposes a positive IPP printer ID and registers DNS-SD |
| TCP IPP attributes | PASS on both architectures, repeated `Get-Printer-Attributes` over TCP 8631 |
| AirPrint formats | PASS, `image/urf`, `image/pwg-raster`, and `urf-supported` advertised |
| Resolution | PASS, 300 DPI supported/default |
| Label media | PASS, `custom_54x70mm_54x70mm` supported/default/ready; collections report 5400 × 7000 units of 0.01 mm |
| DNS-SD | PASS, Avahi browses and resolves `_ipp._tcp` and `_universal._sub._ipp._tcp`; correct container IP, TCP 8631, `rp=ipp/print/Zebra-ZD411`, `pdl` including Apple Raster, and `URF=...RS300` |
| Raster jobs | PASS, PNG, actual Apple Raster and actual PWG Raster submitted with network TCP IPP `Print-Job`; all three jobs complete on both architectures |
| Printer transport | PASS to simulator on TCP 9100, not the physical 192.168.50.110 |
| ZPL output | PASS, three graphics downloads `~DGR:`, three `^XGR:` graphic uses, `^XA`/`^XZ` formats, `^PW637`, direct thermal `^MTD`, gap/web sensing `^MNY` |
| Persistence | PASS, darkness changed to 61, container stopped/removed/replaced with same `/data`, live IPP reports darkness 61 and retains 54 × 70 mm default/ready media |
| Web UI HTTP | PASS, HTTP 200 from TCP 8631; interactive forms/password login not exercised |
| Port conflict | PASS, an existing TCP 8631 listener makes startup fail clearly before launching services |
| Multiple mDNS stacks on one host address | PASS simulated on AMD64: two Avahi daemons in one network namespace; peer owns normal reverse/address records and advertises a synthetic CUPS queue at 631; add-on's A-only advertisement at 8631 and peer queue both resolve |
| Add-on metadata | YAML parsing and option/schema consistency passed; host-network and ARM64 settings checked against current Supervisor source; actual Supervisor installation remains untested |

`evidence/` contains the final native/ARM64 IPP output, jobs, ZPL captures,
DNS-SD records, runtime transcripts and build logs. The GitHub Actions workflow
has been supplied but **has not run on GitHub**; local native and emulated ARM64
results are the evidence for this report.

## Issues found and handled

- The upstream 2-inch driver compares a 10-character prefix using length 16,
  falling through to 4-inch media. The add-on fixes the comparison.
- The stock 2-inch driver has no 54 × 70 mm stock and limits custom width to
  50.8 mm. This ZD411-specific build adds the stock and raises the width to 56 mm.
- Upstream gap tracking emits black-mark sensing `^MNM`; this build maps gap and
  web to `^MNY`.
- PAPPL accumulates duplicate `printer-strings-languages-supported` attributes
  when translated string resources are registered. This build omits LPrint's
  translated resources, retains English, and passes repeated strict IPP queries.
- Newly created queues in PAPPL 1.3.1 expose printer-id zero and do not initialize
  their DNS-SD name until saved state is reloaded. The wrapper performs one
  graceful internal LPrint restart immediately after initial queue creation.
  This happens automatically on first install, before announcing readiness.
- Two mDNS daemons publishing different reverse PTR records for one IP caused
  repeated hostname conflicts in the initial coexistence test. The final add-on
  disables Avahi automatic address publishing and publishes its routed LAN IPv4
  address with `--no-reverse`. The shared-host coexistence test then passed.
- An early discovery assertion could see a different test server's queue.
  Final tests run on isolated networks and require the correct container IP.
  Earlier discovery snapshots are not used as final evidence.

## Exactly what remains untested

1. Installation/build using the real Home Assistant Store/Supervisor on Green,
   ARM64 hardware execution, HAOS **18.3** AppArmor/network behavior, resource
   consumption, backup/restore through Supervisor, updates and host reboot.
2. Discovery in Apple's actual Print dialog on your iPads, including iOS version,
   source-app behavior, IPP negotiation and app-specific page scaling. The
   software tests use real Apple Raster but do not impersonate an iPad's full
   negotiation or its PDF rendering behavior.
3. Your LAN's multicast forwarding, Wi-Fi isolation, IPv4 route selection,
   VLANs/firewall, and coexistence with its actual Home Assistant, CUPS,
   systemd-resolved, Avahi or other Bonjour implementations. The test used a
   second Avahi and a synthetic service, not a complete running CUPS server.
4. Reachability, ZPL mode, firmware and actual status responses of
   **192.168.50.110:9100**. No VPN/private route to that network was available.
5. Whether the Zebra accepts the captured ZPL and prints it correctly: exact
   300/304.8 DPI physical scale, maximum usable width, 54 × 70 mm stock dimensions,
   label-versus-gap pitch, border clipping, orientation, darkness, print speed,
   tear offset and sensor calibration. The simulator cannot prove these.
6. Physical fault/recovery cases: media out, cover open, printer reboot, bad
   network, retry behavior, queued jobs across sudden power loss and duplicate
   prints after interrupted delivery.
7. Thermal-transfer/ribbon mode: configured but not physically tested. Physical
   cutter/peeler/RFID options inherited from the generic driver are not validated
   for this ZD411 and should not be selected without the corresponding hardware.
8. Interactive LPrint web forms/security setup and real Home Assistant backup
   restores. Persistent state was verified through graceful container replacement;
   this is not a sudden-power-loss durability test.

## Hardware acceptance test, without SSH

1. Publish the repository, add its GitHub URL through the Home Assistant Store,
   Install/Start and enable Start on boot. Confirm the Log tab says ready. Check
   existing unrelated printers remain visible.
2. Open the Web UI from the iPad. Verify the queue's URI, 300 DPI, 54 × 70 mm
   loaded/default media and sensing. Match direct thermal or ribbon mode.
3. Use a correctly sized single-page label document with a border and a known-size
   mark. In the iPad Print dialog select Zebra-ZD411 and print **one** copy.
   Check centering, dimensions, orientation, gap feed and readable barcode/text.
4. Change darkness once in the web UI, restart the add-on in Home Assistant,
   and confirm the setting persists. Reboot Home Assistant from its UI and verify
   rediscovery and a second single-label print.
5. With only expendable labels and one test job, test media-out and printer
   reconnect recovery. Inspect job state in the web UI before resubmitting to
   avoid duplicates. Record the iOS version/app and measured output.

Only after those checks pass should this installation be described as working
on your physical hardware.

## Reproduce developer tests

These commands are for a developer Docker runner, **not** the Home Assistant host.
The same suite runs natively in the supplied GitHub workflow on AMD64 and ARM64.

```sh
docker build -t ha-lprint:test lprint
python3 tests/integration.py ha-lprint:test
```

The suite uses checked-in PNG/URF/PWG fixtures. `tests/make-label.py` and
`tests/make-raster.c` are their generators; the latter uses libcups's actual
Apple/PWG raster encoders. `tests/Dockerfile` provides an optional compiler helper.
The suite tests the unchanged production image, with test fixtures mounted read
only, and stores results under `tests/results/`.

For this x86 cloud runner's ARM64 test specifically:

```sh
docker buildx build --builder BUILDER_WITH_QEMU --platform linux/arm64 \
  --load -t ha-lprint:arm64 lprint
LPRINT_QEMU_PATH=/absolute/path/to/buildkit-qemu-aarch64 \
  python3 tests/integration.py ha-lprint:arm64
```

BuildKit's bundled emulator is used because this environment cannot retain normal
binfmt registrations. A native ARM64 runner requires neither this mount nor
privileged containers. The only privileged test setup was the attempted emulator
registration/build infrastructure, not the add-on runtime.

`tests/mdns-peer.sh` starts the synthetic peer when run in a second test container
with `--network container:ADDON_TEST_CONTAINER`; `tests/port-conflict.py` checks
occupied-port startup in a disposable container with options and tests mounted.
