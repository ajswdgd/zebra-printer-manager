"""Ingress-only HTTP API and UI. No external dependencies or LAN admin endpoint."""
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import html
import ipaddress
import json
import logging
import os
from pathlib import Path
import threading
from urllib.parse import urlsplit, unquote

from .discovery import discover, scan_hosts
from .model import printer, UserError

LOG=logging.getLogger('zebra')
STATIC=Path(__file__).parent/'static'

class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __init__(self,runtime,port):
        self.runtime=runtime;self.discovery={'running':False,'printers':[],'warnings':[]}
        self.discovery_lock=threading.Lock()
        super().__init__(('0.0.0.0',port),Handler)

class Handler(BaseHTTPRequestHandler):
    server_version='ZebraManager/0.2'
    def log_message(self,fmt,*args):
        # Do not log Ingress paths/tokens, user headers, or query strings.
        LOG.info('Manager HTTP %s',args[1] if len(args)>1 else 'request')
    def setup(self):
        super().setup();self.connection.settimeout(30)
    def send(self,value,code=200,mime='application/json'):
        body=json.dumps(value,allow_nan=False).encode() if mime=='application/json' else value
        self.send_response(code)
        self.send_header('Content-Type',mime+'; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; object-src 'none'")
        self.end_headers();self.wfile.write(body)
    def allowed(self):
        # The TCP peer is authoritative. Never trust a caller's forwarded IP header.
        return self.client_address[0]=='172.30.32.2' or (os.environ.get('ZPM_TEST_MODE')=='1' and self.client_address[0]=='127.0.0.1')
    def handle_request(self,method):
        if not self.allowed():return self.send({'error':'Open Zebra Printer Manager through Home Assistant Ingress.'},403)
        path=unquote(urlsplit(self.path).path)
        try:
            body={}
            if method not in ('GET',):
                if self.headers.get('X-Zebra-Manager')!='1' or self.headers.get_content_type()!='application/json':
                    raise UserError('Use the Home Assistant management interface for changes.',403)
                length=int(self.headers.get('Content-Length','0'))
                if not 0<=length<=16384:raise UserError('Request is too large.',413)
                body=json.loads(self.rfile.read(length) or b'{}')
                if not isinstance(body,dict):raise UserError('Settings must be a JSON object.')
            runtime=self.server.runtime
            if method=='GET' and path=='/':
                base=self.headers.get('X-Ingress-Path','/').rstrip('/')+'/'
                if not base.startswith('/') or base.startswith('//') or any(c in base for c in '\r\n'):
                    raise UserError('Invalid Ingress path.')
                content=(STATIC/'index.html').read_text().replace('__BASE__',html.escape(base,quote=True))
                return self.send(content.encode(),mime='text/html')
            if method=='GET' and path in ('/assets/app.js','/assets/style.css'):
                filename='app.js' if path.endswith('.js') else 'style.css'
                return self.send((STATIC/filename).read_bytes(),mime='text/javascript' if filename.endswith('.js') else 'text/css')
            if method=='GET' and path=='/api/state':
                value=runtime.snapshot()
                with self.server.discovery_lock:value['discovery']=deepcopy(self.server.discovery)
                return self.send(value)
            if method=='GET' and path=='/api/logs':return self.send({'lines':list(runtime.lines)})
            if method=='GET' and path=='/api/diagnostics':
                return self.send({'state':runtime.snapshot(),'logs':list(runtime.lines),'note':'May contain LAN addresses and queue names. No label content is exported.'})
            if method=='POST' and path=='/api/refresh':
                runtime.refresh();return self.send({'message':'Status refreshed.'})
            if method=='POST' and path=='/api/discover':
                subnet=body.get('subnet') or None
                if subnet:scan_hosts(subnet)
                with self.server.discovery_lock:
                    if self.server.discovery['running']:raise UserError('Discovery is already running.',409)
                    self.server.discovery={'running':True,'printers':[],'warnings':[]}
                def worker():
                    try:
                        printers,warnings=discover(subnet)
                        # Do not offer this add-on's AirPrint bridge as a physical printer.
                        printers=[p for p in printers if p['port']!=runtime.port]
                    except Exception as error:
                        LOG.exception('Discovery failed');printers,warnings=[],[str(error)]
                    with self.server.discovery_lock:self.server.discovery={'running':False,'printers':printers,'warnings':warnings}
                threading.Thread(target=worker,daemon=True).start()
                return self.send({'message':'Searching for Zebra printers…'},202)
            parts=path.strip('/').split('/')
            if parts[:2]==['api','printers']:
                if method=='POST' and len(parts)==4 and parts[3]=='test':return self.send(runtime.test_label(parts[2]),202)
                if method=='POST' and len(parts)==4 and parts[3]=='cancel':return self.send(runtime.cancel_jobs(parts[2]))
                if method in ('POST','PUT','DELETE') and len(parts) in (2,3):
                    with runtime.lock:
                        new=deepcopy(runtime.config)
                        existing=parts[2] if len(parts)==3 else None
                        if method in ('PUT','DELETE') and not any(p['id']==existing for p in new['printers']):raise UserError('Printer not found.',404)
                        if method=='DELETE':new['printers']=[p for p in new['printers'] if p['id']!=existing]
                        else:
                            p=printer(body,existing)
                            if method=='POST':
                                if len(new['printers'])>=16:raise UserError('This manager supports up to 16 queues.')
                                if any(x['id'].casefold()==p['id'].casefold() for x in new['printers']):raise UserError('That AirPrint name is already in use.',409)
                                if any((x['address'],x['port'])==(p['address'],p['port']) for x in new['printers']):raise UserError('That printer address is already configured.',409)
                                new['printers'].append(p)
                            else:
                                if any(x['id']!=existing and (x['address'],x['port'])==(p['address'],p['port']) for x in new['printers']):raise UserError('That printer address is already configured.',409)
                                new['printers']=[p if x['id']==existing else x for x in new['printers']]
                        runtime.configure(new)
                        return self.send({'message':'Printer settings saved. AirPrint is advertised automatically.'})
            raise UserError('Page or action not found.',404)
        except UserError as error:self.send({'error':str(error)},error.status)
        except (ValueError,TypeError,KeyError) as error:self.send({'error':str(error)},400)
        except Exception:
            LOG.exception('Manager request failed');self.send({'error':'The service could not complete that action. See Diagnostics.'},503)
    def do_GET(self):self.handle_request('GET')
    def do_POST(self):self.handle_request('POST')
    def do_PUT(self):self.handle_request('PUT')
    def do_DELETE(self):self.handle_request('DELETE')
