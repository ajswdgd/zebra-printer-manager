"""Generate a physical-size PNG diagnostic label; submit through LPrint, not raw ZPL."""
import struct
import zlib

FONT={
' ':['000']*5,'0':['111','101','101','101','111'],'1':['010','110','010','010','111'],
'2':['111','001','111','100','111'],'3':['111','001','111','001','111'],'4':['101','101','111','001','001'],
'5':['111','100','111','001','111'],'6':['111','100','111','101','111'],'7':['111','001','010','010','010'],
'8':['111','101','111','101','111'],'9':['111','101','111','001','111'],'.':['000','000','000','000','010'],
'Z':['111','001','010','100','111'],'E':['111','100','110','100','111'],'B':['110','101','110','101','110'],
'R':['110','101','110','101','101'],'A':['010','101','111','101','101'],'T':['111','010','010','010','010'],
'S':['111','100','111','001','111'],'M':['101','111','111','101','101'],'D':['110','101','101','101','110'],
'P':['110','101','110','100','100'],'I':['111','010','010','010','111'],'X':['101','101','010','101','101']}

def png(p):
    w,h=round(p['width_mm']*p['dpi']/25.4),round(p['height_mm']*p['dpi']/25.4)
    if w*h>16000000:
        raise ValueError('This test label is too large. Use a shorter label (16 megapixels maximum).')
    pixels=bytearray(b'\xff')*(w*h)
    def rect(x,y,dx,dy):
        for row in range(max(0,y),min(h,y+dy)):
            a,b=max(0,x),min(w,x+dx)
            if b>a:
                pixels[row*w+a:row*w+b]=b'\x00'*(b-a)
    margin=max(4,round(p['dpi']*2/25.4)); stroke=max(1,p['dpi']//150)
    rect(margin,margin,w-2*margin,stroke);rect(margin,h-margin,w-2*margin,stroke)
    rect(margin,margin,stroke,h-2*margin);rect(w-margin,margin,stroke,h-2*margin)
    scale=max(1,min(p['dpi']//75,(w-2*margin)//50))
    def text(value,y):
        x=margin+stroke*3
        for c in value:
            for row,pattern in enumerate(FONT.get(c,FONT[' '])):
                for col,bit in enumerate(pattern):
                    if bit=='1':rect(x+col*scale,y+row*scale,scale,scale)
            x+=4*scale
    text('ZEBRA TEST',margin+8*stroke)
    text(f'{p["width_mm"]:g} X {p["height_mm"]:g} MM',margin+8*stroke+8*scale)
    text(f'{p["dpi"]} DPI',margin+8*stroke+16*scale)
    side=round(10*p['dpi']/25.4); y=margin+8*stroke+25*scale
    rect(margin+10,y,side,stroke);rect(margin+10,y+side,side,stroke)
    rect(margin+10,y,stroke,side);rect(margin+10+side,y,stroke,side)
    def chunk(kind,data):
        return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data))
    raw=b''.join(b'\0'+pixels[y*w:(y+1)*w] for y in range(h))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',w,h,8,0,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')
