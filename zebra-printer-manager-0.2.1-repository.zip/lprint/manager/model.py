"""Validated persistent settings and migration from the original add-on."""
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import shlex
from urllib.parse import urlsplit

class UserError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status

def atomic_json(path, value):
    path = Path(path)
    pending = path.with_suffix('.tmp')
    with pending.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    pending.replace(path)
    fd = os.open(str(path.parent), os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def number(value, label, low, high, integer=False):
    if isinstance(value, bool):
        raise UserError(f'{label} must be a number.')
    try:
        n = float(value)
    except (ValueError, TypeError):
        raise UserError(f'{label} must be a number.')
    if not math.isfinite(n) or not low <= n <= high or (integer and n != int(n)):
        raise UserError(f'{label} must be between {low} and {high}' + (' (whole numbers).' if integer else '.'))
    return int(n) if integer else round(n, 2)

def printer(value, existing_id=None):
    if not isinstance(value, dict):
        raise UserError('Printer settings must be an object.')
    name = str(value.get('name', '')).strip()
    if not name or len(name) > 60 or any(ord(c) < 32 for c in name):
        raise UserError('Enter a printer name of 1–60 characters.')
    queue = existing_id or value.get('id') or ('Zebra-' + re.sub('[^A-Za-z0-9_-]+', '-', name).strip('-'))
    if not isinstance(queue, str) or not re.fullmatch('[A-Za-z][A-Za-z0-9_-]{0,62}', queue):
        raise UserError('AirPrint name must start with a letter and contain only letters, numbers, hyphens or underscores (63 maximum).')
    address = str(value.get('address', '')).strip().lower()
    if not address or len(address) > 253 or not re.fullmatch('[A-Za-z0-9][A-Za-z0-9.-]*', address):
        raise UserError('Enter an IPv4 address or DNS hostname, without a URL or port.')
    if re.fullmatch('[0-9.]+', address):
        try:
            ipaddress.IPv4Address(address)
        except ValueError:
            raise UserError('That IPv4 address is invalid.')
    dpi = number(value.get('dpi', 300), 'DPI', 203, 600, True)
    if dpi not in (203, 300, 600):
        raise UserError('Choose 203, 300 or 600 DPI to match the physical printhead.')
    width = number(value.get('width_mm', 54), 'Label width', 19.05, 104)
    height = number(value.get('height_mm', 70), 'Label length', 6.35, 1000)
    sensing = value.get('sensing', 'gap')
    if sensing not in ('gap', 'mark', 'continuous'):
        raise UserError('Choose gap, black mark, or continuous sensing.')
    transfer = value.get('thermal_transfer', False)
    if not isinstance(transfer, bool):
        raise UserError('Thermal transfer must be true or false.')
    if dpi == 600 and not transfer:
        raise UserError('The LPrint 600 DPI ZPL driver supports thermal transfer only.')
    return dict(id=queue, name=name, address=address, port=number(value.get('port', 9100), 'Printer port', 1, 65535, True),
                dpi=dpi, width_mm=width, height_mm=height, sensing=sensing, thermal_transfer=transfer,
                darkness=number(value.get('darkness', 50), 'Darkness', 0, 100, True))

def media(p):
    size = f'{p["width_mm"]:g}x{p["height_mm"]:g}mm'
    return f'custom_{size}_{size}'

def driver(p):
    width = 56 if p['dpi'] == 300 else 50.8
    return f'zpl_{"2inch" if p["width_mm"] <= width else "4inch"}-{p["dpi"]}dpi-{"tt" if p["thermal_transfer"] else "dt"}'

def read_legacy(data, options):
    path = Path(data) / '.lprint.conf'
    migrated = []
    if path.exists():
        text = path.read_text()
        for match in re.finditer(r'<Printer\s+(.*?)>\n(.*?)</Printer>', text, re.S):
            fields = dict(item.split('=', 1) for item in shlex.split(match[1]) if '=' in item)
            if not fields.get('driver', '').startswith('zpl_'):
                continue
            uri = urlsplit(fields.get('uri', ''))
            if uri.scheme != 'socket' or not uri.hostname:
                continue
            body = match[2]
            sizes = re.search(r'^media-col-default\s+(.*)$', body, re.M)
            sizes = dict(x.split('=', 1) for x in shlex.split(sizes[1]) if '=' in x) if sizes else {}
            dark = re.search(r'^printer-darkness-configured (\d+)', body, re.M)
            migrated.append(printer(dict(id=fields['name'], name=fields['name'], address=uri.hostname, port=uri.port or 9100,
                dpi=int(re.search(r'-(\d+)dpi', fields['driver'])[1]), thermal_transfer='-tt' in fields['driver'],
                width_mm=int(sizes.get('width', 5400))/100, height_mm=int(sizes.get('length', 7000))/100,
                sensing={'web':'gap'}.get(sizes.get('tracking'), sizes.get('tracking', 'gap')), darkness=int(dark[1]) if dark else 50)))
        backup = Path(data) / 'pre-manager-lprint.conf'
        if not backup.exists():
            backup.write_text(text)
    if not migrated:
        migrated = [printer(dict(id='Zebra-ZD411', name='Zebra ZD411', address=options.get('printer_ip', '192.168.50.110'),
            port=options.get('printer_port',9100), thermal_transfer=options.get('thermal_transfer',False)))]
    return {'version':1, 'printers':migrated}

def load(data, options):
    path = Path(data) / 'manager.json'
    if not path.exists():
        return read_legacy(data, options)
    value = json.loads(path.read_text())
    if value.get('version') != 1 or not isinstance(value.get('printers'), list) or len(value['printers']) > 16:
        raise UserError('Unsupported manager configuration. Restore an add-on backup.')
    value['printers'] = [printer(p) for p in value['printers']]
    if len({p['id'].casefold() for p in value['printers']}) != len(value['printers']):
        raise UserError('Duplicate AirPrint names in saved settings.')
    return value
