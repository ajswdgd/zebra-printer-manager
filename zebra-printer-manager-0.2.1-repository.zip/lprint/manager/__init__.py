"""Zebra Printer Manager, backed by the existing LPrint service."""

__version__ = "0.2.1"
