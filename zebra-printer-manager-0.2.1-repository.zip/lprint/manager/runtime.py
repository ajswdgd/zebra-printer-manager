"""Lifecycle and serialized queue changes around the preserved LPrint backend."""
from collections import deque
from copy import deepcopy
import json
import fcntl
import struct
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import socket
import shlex
import subprocess
import sys
import threading
import time
import urllib.request

from . import ipp, __version__
from .startup import wait_for_dbus, wait_for_avahi, avahi_hostname
from .label import png
from .model import atomic_json, driver, load, media, UserError

LOG = logging.getLogger('zebra')

class Runtime:
    def __init__(self, data='/data'):
        self.data=Path(data); self.data.mkdir(exist_ok=True)
        self.options=json.loads((self.data/'options.json').read_text())
        self.port=int(self.options.get('ipp_port',8631))
        if not 1<=self.port<=65535:raise UserError('Invalid IPP port.')
        self.config=load(self.data,self.options)
        self.lock=threading.RLock(); self.children={}; self.lines=deque(maxlen=250)
        self.stop_event=threading.Event(); self.statuses={}; self.last_test={}; self.last_error=None
        (self.data/'logs').mkdir(exist_ok=True)
        LOG.setLevel(logging.INFO)
        formatter=logging.Formatter('%(asctime)s %(levelname)s %(message)s')
        for handler in (logging.StreamHandler(sys.stdout),RotatingFileHandler(self.data/'logs/manager.log',maxBytes=750000,backupCount=2)):
            handler.setFormatter(formatter); LOG.addHandler(handler)
        os.environ['XDG_DATA_HOME']=str(self.data)
        os.environ['ZEBRA_MEDIA_DIR']=str(self.data/'media')
        os.environ['DBUS_SYSTEM_BUS_ADDRESS']='unix:path=/run/dbus/system_bus_socket'
        self.hostname='lprint-zd411.local'

    def spawn(self,name,args):
        process=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        self.children[name]=process
        def reader():
            for line in process.stdout:
                line=line.rstrip()[:2000]
                self.lines.append(f'{name}: {line}')
                LOG.info('%s: %s',name,line)
        threading.Thread(target=reader,daemon=True).start()
        return process

    def halt(self,name):
        process=self.children.pop(name,None)
        if process and process.poll() is None:
            process.terminate()
            try:process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                process.kill();process.wait();raise RuntimeError(f'{name} did not stop cleanly.')

    def cli(self,*args):
        try:
            result=subprocess.run(['lprint',*args],capture_output=True,text=True,timeout=20)
        except subprocess.TimeoutExpired:
            raise UserError('LPrint timed out. Check Diagnostics before trying again.',503)
        if result.returncode:
            LOG.error('LPrint %s failed: %s',args[0],result.stderr.strip())
            raise UserError('LPrint could not apply the request: '+result.stderr.strip()[:400],503)
        return result.stdout.strip()

    def start_lprint(self):
        # A transient libavahi/DBus startup assertion was observed under ARM64
        # emulation. Recover a bounded number of times, logging each failure.
        for attempt in range(1,4):
            Path('/run/lprint.sock').unlink(missing_ok=True)
            process=self.spawn('lprint',['lprint','server','-o',f'server-port={self.port}','-o',f'server-hostname={self.hostname}',
                '-o',f'spool-directory={self.data}/spool','-o','server-options=no-web-interface','-o','log-file=-',
                '-o',f'log-level={self.options.get("log_level","info")}'])
            for _ in range(200):
                if process.poll() is not None:break
                if Path('/run/lprint.sock').exists():
                    try:self.cli('printers');return
                    except UserError:pass
                time.sleep(.1)
            self.halt('lprint')
            LOG.warning('LPrint startup attempt %s/3 failed; see preceding service logs.',attempt)
            if attempt<3:time.sleep(.3*attempt)
        raise RuntimeError('LPrint failed to start after three attempts. See Diagnostics / add-on logs.')

    def media_files(self,config):
        directory=self.data/'media';directory.mkdir(exist_ok=True)
        for file in directory.glob('*.txt'):file.unlink()
        for p in config['printers']:(directory/(p['id']+'.txt')).write_text(media(p)+'\n')
        (directory/'driver-map.txt').write_text(''.join(f'socket://{p["address"]}:{p["port"]} {media(p)}\n' for p in config['printers']))

    def start(self):
        with socket.socket() as probe:probe.bind(('0.0.0.0',self.port))
        Path('/run/dbus').mkdir(parents=True,exist_ok=True)
        subprocess.run(['dbus-uuidgen','--ensure'],check=True,timeout=5)
        dbus_process=self.spawn('dbus',['dbus-daemon','--system','--nofork','--nopidfile'])
        wait_for_dbus(dbus_process)
        avahi_process=self.spawn('avahi',['avahi-daemon','--no-chroot'])
        wait_for_avahi(avahi_process,dbus_process)
        self.hostname=avahi_hostname(avahi_process)
        address=self.config['printers'][0]['address'] if self.config['printers'] else self.options.get('printer_ip','192.168.50.110')
        advertise=None
        try:
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as route:
                route.connect((address,9100));advertise=route.getsockname()[0]
            if advertise.startswith('127.'):advertise=socket.gethostbyname(socket.gethostname())
        except OSError:
            LOG.warning('Cannot select a route to the configured printer; using a host interface for discovery.')
        if not advertise or advertise.startswith('127.'):
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as probe:
                for _,interface in socket.if_nameindex():
                    if interface.startswith(('lo','docker','veth','br-','hassio')):continue
                    try:
                        result=fcntl.ioctl(probe.fileno(),0x8915,struct.pack('256s',interface.encode()[:15]))
                        advertise=socket.inet_ntoa(result[20:24]);break
                    except OSError:continue
        if advertise and not advertise.startswith('127.'):
            self.spawn('address',['avahi-publish-address','--no-reverse',self.hostname,advertise])
        else:
            LOG.error('No LAN IPv4 address is available for AirPrint advertising. Management remains available; check networking.')
        self.media_files(self.config);self.start_lprint()
        applied=self.data/'manager-applied.json'
        saved=json.loads(applied.read_text()) if applied.exists() else None
        queues=set(self.cli('printers').splitlines())
        # lprint printers includes descriptions; use the state file for exact IDs.
        state=(self.data/'.lprint.conf').read_text() if (self.data/'.lprint.conf').exists() else ''
        if saved!=self.config or any(f'name="{p["id"]}"' not in state for p in self.config['printers']):
            self.configure(self.config,initial=True)
        elif not (self.data/'manager.json').exists():
            atomic_json(self.data/'manager.json',self.config)
        LOG.info('LPrint ready on port %s; Zebra Printer Manager initialized',self.port)
        threading.Thread(target=self.monitor,daemon=True).start()

    def configure(self,new,initial=False):
        with self.lock:
            if not initial:
                for p in self.config['printers']:
                    try:info=ipp.status(self.port,p['id'])
                    except Exception:raise UserError('Cannot verify the print queue. Check the service log before changing settings.',503)
                    if info['queued_jobs'] or info['state']=='printing':
                        raise UserError('Printing or queued jobs are present. Let them finish or cancel them before changing printers.',409)
            old=deepcopy(self.config)
            self.halt('lprint')
            state_path=self.data/'.lprint.conf'
            backup=state_path.read_bytes() if state_path.exists() else None
            try:
                # PAPPL 1.3.1's modify CLI ignores -m and -v. Update only those
                # two serialized fields while the server is stopped, preserving
                # printer IDs, UUIDs, completed jobs and all unrelated state.
                if state_path.exists():
                    wanted={p['id']:p for p in new['printers']}
                    def queue_header(match):
                        header=match[0]
                        fields=dict(v.split('=',1) for v in shlex.split(header[len('<Printer '):-1]) if '=' in v)
                        p=wanted.get(fields.get('name'))
                        if p:
                            header=re.sub(r'driver="[^"]*"','driver="'+driver(p)+'"',header)
                            header=re.sub(r'uri="[^"]*"','uri="socket://'+p['address']+':'+str(p['port'])+'"',header)
                        return header
                    state_path.write_text(re.sub(r'<Printer [^>\n]*>',queue_header,state_path.read_text()))
                self.media_files(new);self.start_lprint()
                known=self.cli('printers')
                for p in old['printers']:
                    if p['id'] not in {x['id'] for x in new['printers']}:
                        self.cli('delete','-d',p['id'])
                for p in new['printers']:
                    action='modify' if re.search(r'^'+re.escape(p['id'])+r'(?:\s|$)',known,re.M) else 'add'
                    if action=='add':self.cli('add','-d',p['id'],'-m',driver(p),'-v',f'socket://{p["address"]}:{p["port"]}')
                # Preserve the original fix for PAPPL's fresh queue ID / DNS-SD initialization.
                self.halt('lprint');self.start_lprint()
                for p in new['printers']:
                    self.cli('modify','-d',p['id'],'-o',f'printer-resolution={p["dpi"]}dpi','-o','label-mode-configured=tear-off',
                        '-o',f'printer-darkness-configured={p["darkness"]}')
                    ipp.set_media(self.port,p)
                # Flush and reload, so defaults and fresh queues are durable before success.
                self.halt('lprint');self.start_lprint()
                atomic_json(self.data/'manager.json',new)
                atomic_json(self.data/'manager-applied.json',new)
                self.config=deepcopy(new);self.statuses={};self.last_error=None
                LOG.info('Printer configuration applied: %s queue(s)',len(new['printers']))
            except Exception as error:
                LOG.exception('Configuration failed; restoring previous queues')
                self.halt('lprint')
                if backup is not None:state_path.write_bytes(backup)
                else:state_path.unlink(missing_ok=True)
                self.media_files(old);self.config=old;self.start_lprint()
                self.last_error=str(error)
                raise

    def refresh(self):
        with self.lock:
            for p in self.config['printers']:
                info={'checked_at':time.time(),'reachable':False,'state':'unknown','reasons':['Status not yet available'],'queued_jobs':None}
                try:
                    with socket.create_connection((p['address'],p['port']),timeout=1):pass
                    info['reachable']=True
                except OSError:
                    info['error']='Cannot connect. Check printer power, address, port and network.'
                try:info.update(ipp.status(self.port,p['id']))
                except Exception:
                    info['error']='LPrint status is unavailable. Open Diagnostics.'
                self.statuses[p['id']]=info

    def monitor(self):
        while not self.stop_event.is_set():
            try:self.refresh()
            except Exception:LOG.exception('Status refresh failed')
            self.stop_event.wait(15)

    def snapshot(self):
        with self.lock:
            return {'version':__version__,'service':'running' if self.children.get('lprint') and self.children['lprint'].poll() is None else 'unavailable',
                'ipp_port':self.port,'printers':[dict(p,status=self.statuses.get(p['id'],{'state':'checking','reachable':None})) for p in self.config['printers']],
                'last_error':self.last_error,'hardware_verified':False}

    def test_label(self,queue):
        with self.lock:
            p=next((p for p in self.config['printers'] if p['id']==queue),None)
            if not p:raise UserError('Printer not found.',404)
            if time.monotonic()-self.last_test.get(queue,-100)<5:raise UserError('A test was just submitted. Check the queue before printing another.',429)
            try:
                with socket.create_connection((p['address'],p['port']),timeout=2):pass
            except OSError:raise UserError('Printer is unreachable. No test label was submitted.',409)
            try:content=png(p)
            except ValueError as error:raise UserError(str(error))
            directory=self.data/'test-labels';directory.mkdir(exist_ok=True)
            path=directory/(queue+'.png');path.write_bytes(content)
            job=self.cli('submit','-d',queue,str(path))
            self.last_test[queue]=time.monotonic()
            LOG.info('Test label submitted to %s: %s',queue,job)
            return {'message':'Test label submitted to LPrint. Check the physical label before submitting another.','job':job}

    def cancel_jobs(self,queue):
        with self.lock:
            if not any(p['id']==queue for p in self.config['printers']):raise UserError('Printer not found.',404)
            self.cli('cancel','-d',queue,'-a')
            LOG.info('Pending jobs cancelled for %s',queue)
            return {'message':'Pending jobs cancelled. Check whether a label already printed before submitting another.'}

    def ingress_port(self):
        token=os.environ.get('SUPERVISOR_TOKEN')
        if not token:return 8099  # Standalone developer tests; access remains restricted.
        request=urllib.request.Request('http://supervisor/addons/self/info',headers={'Authorization':'Bearer '+token})
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request,timeout=10) as response:
            port=int(json.load(response)['data']['ingress_port'])
        if not 1<=port<=65535:raise RuntimeError('Supervisor did not provide an Ingress port.')
        return port

    def check(self):
        with self.lock:
            for name,process in self.children.items():
                if process.poll() is not None:raise RuntimeError(f'{name} exited unexpectedly ({process.returncode}). See diagnostic log.')

    def close(self):
        self.stop_event.set()
        with self.lock:
            for name in reversed(list(self.children)):self.halt(name)
