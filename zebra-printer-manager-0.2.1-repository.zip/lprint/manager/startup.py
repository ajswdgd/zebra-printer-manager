"""Bounded private D-Bus/Avahi readiness checks, separate from LPrint retries."""
import re
import subprocess
import time


def _request(destination, path, method, remaining):
    """Bound both D-Bus's reply wait and the lifetime of the client subprocess."""
    milliseconds = max(1, min(1000, int(remaining * 1000)))
    return subprocess.run(
        ['dbus-send', '--system', '--print-reply', f'--reply-timeout={milliseconds}',
         f'--dest={destination}', path, method],
        capture_output=True, text=True, timeout=min(2.0, remaining),
    )


def _wait(process, name, destination, path, method, accepted, timeout, dependencies=()):
    deadline = time.monotonic() + timeout
    while True:
        for label, child in ((name, process), *dependencies):
            status = child.poll()
            if status is not None:
                raise RuntimeError(f'{label} exited during startup (status {status}). See service logs.')
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise RuntimeError(f'{name} did not become ready within {timeout:g}s. See service logs.')
        try:
            reply = _request(destination, path, method, remaining)
        except subprocess.TimeoutExpired:
            reply = None
        except OSError:
            raise RuntimeError(f'{name} readiness client could not run. See service logs.') from None
        if reply is not None and reply.returncode == 0 and accepted(reply.stdout):
            return
        time.sleep(min(0.1, max(0.0, deadline - time.monotonic())))


def wait_for_dbus(process, timeout=10):
    """A socket file may be stale; require a successful private bus round trip."""
    _wait(process, 'Private D-Bus', 'org.freedesktop.DBus', '/org/freedesktop/DBus',
          'org.freedesktop.DBus.ListNames', lambda output: True, timeout)


def wait_for_avahi(process, dbus_process, timeout=15):
    """Require Avahi's RUNNING state and check both child processes remain alive."""
    _wait(process, 'Avahi', 'org.freedesktop.Avahi', '/',
          'org.freedesktop.Avahi.Server.GetState',
          lambda output: re.search(r'\bint32\s+2\b', output) is not None, timeout,
          dependencies=(('Private D-Bus', dbus_process),))


def avahi_hostname(process):
    if process.poll() is not None:
        raise RuntimeError('Avahi exited before hostname lookup. See service logs.')
    try:
        reply = _request('org.freedesktop.Avahi', '/',
                         'org.freedesktop.Avahi.Server.GetHostNameFqdn', 2.0)
    except (subprocess.TimeoutExpired, OSError):
        raise RuntimeError('Avahi hostname lookup failed or timed out. See service logs.') from None
    match = re.search(r'string "([^"\r\n]+)"', reply.stdout)
    if reply.returncode != 0 or match is None:
        raise RuntimeError('Avahi did not return a valid hostname. See service logs.')
    return match[1]
