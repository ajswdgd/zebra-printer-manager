"""Small, bounded IPP status client; LPrint remains the actual print service."""
import http.client
import struct

REQUESTED = ('printer-state','printer-state-reasons','printer-is-accepting-jobs','queued-job-count')

def attr(tag, name, value):
    name, value = name.encode(), value.encode()
    return bytes([tag]) + struct.pack('!H',len(name)) + name + struct.pack('!H',len(value)) + value

def status(port, queue):
    path = '/ipp/print/' + queue
    request = b'\x02\x00\x00\x0b\x00\x00\x00\x01\x01'
    request += attr(0x47,'attributes-charset','utf-8') + attr(0x48,'attributes-natural-language','en')
    request += attr(0x45,'printer-uri',f'ipp://localhost:{port}{path}')
    for i, name in enumerate(REQUESTED):
        request += attr(0x44,'requested-attributes' if i == 0 else '',name)
    request += b'\x03'
    connection = http.client.HTTPConnection('127.0.0.1',port,timeout=3)
    try:
        connection.request('POST',path,body=request,headers={'Content-Type':'application/ipp'})
        reply = connection.getresponse()
        data = reply.read(65537)
        if reply.status != 200 or len(data) < 8 or len(data)>65536 or struct.unpack('!H',data[2:4])[0] >= 0x400:
            raise OSError('LPrint did not return a successful IPP status response')
    finally:
        connection.close()
    values, offset, name = {}, 8, ''
    while offset < len(data):
        tag = data[offset]; offset += 1
        if tag == 3:
            break
        if tag < 0x10:
            continue
        size = struct.unpack_from('!H',data,offset)[0]; offset += 2
        if size:
            name = data[offset:offset+size].decode('utf-8','replace')
        offset += size
        size = struct.unpack_from('!H',data,offset)[0]; offset += 2
        raw = data[offset:offset+size]; offset += size
        if tag in (0x21,0x23) and size == 4:
            value = struct.unpack('!i',raw)[0]
        elif tag == 0x22 and size == 1:
            value = bool(raw[0])
        else:
            value = raw.decode('utf-8','replace')
        values.setdefault(name,[]).append(value)
    return {'state':{3:'idle',4:'printing',5:'stopped'}.get(values.get('printer-state',[0])[0],'unknown'),
        'reasons':values.get('printer-state-reasons',['unknown']),
        'accepting_jobs':values.get('printer-is-accepting-jobs',[False])[0],
        'queued_jobs':values.get('queued-job-count',[0])[0]}

def value_attr(tag,name,value):
    name=name.encode()
    if isinstance(value,str):value=value.encode()
    return bytes([tag])+struct.pack('!H',len(name))+name+struct.pack('!H',len(value))+value

def media_collection(name,p):
    from .model import media
    def member(key,tag,value):
        if tag==0x21:value=struct.pack('!i',value)
        return value_attr(0x4a,'',key)+value_attr(tag,'',value)
    content=member('x-dimension',0x21,round(p['width_mm']*100))+member('y-dimension',0x21,round(p['height_mm']*100))
    col=value_attr(0x34,name,b'')+value_attr(0x4a,'','media-size')+value_attr(0x34,'',b'')+content+value_attr(0x37,'',b'')
    for key,val in [('media-size-name',media(p)),('media-source','main-roll'),('media-type','continuous' if p['sensing']=='continuous' else 'labels'),('media-tracking',p['sensing'])]:
        col+=member(key,0x44,val)
    for key in ('media-bottom-margin','media-left-margin','media-right-margin','media-top-margin'):
        col+=member(key,0x21,1)
    return col+value_attr(0x37,'',b'')

def set_media(port,p):
    """Set ready AND default collections; PAPPL's ready setter overrides defaults."""
    path='/ipp/print/'+p['id']
    request=b'\x02\x00\x00\x13\x00\x00\x00\x02\x01'
    request+=attr(0x47,'attributes-charset','utf-8')+attr(0x48,'attributes-natural-language','en')
    request+=attr(0x45,'printer-uri',f'ipp://localhost:{port}{path}')
    request+=b'\x04'+media_collection('media-col-default',p)+media_collection('media-col-ready',p)+b'\x03'
    conn=http.client.HTTPConnection('127.0.0.1',port,timeout=5)
    try:
        conn.request('POST',path,body=request,headers={'Content-Type':'application/ipp'})
        reply=conn.getresponse();body=reply.read(65536)
        if reply.status!=200 or len(body)<8 or struct.unpack('!H',body[2:4])[0]>=0x400:
            raise OSError('LPrint rejected the loaded/default label settings.')
    finally:conn.close()
