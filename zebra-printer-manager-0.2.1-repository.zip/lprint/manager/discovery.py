"""Read-only Zebra discovery: DNS-SD plus a bounded, optional local subnet scan."""
from concurrent.futures import ThreadPoolExecutor
import ipaddress
import re
import socket
import subprocess

ZEBRA = re.compile(r'ZEBRA|\bZTC\b|\b(?:ZD|ZT|GK|GX|ZQ|QLN)\d{3}', re.I)

def identify(address, port=9100, timeout=.7):
    try:
        with socket.create_connection((address,port),timeout=timeout) as conn:
            conn.settimeout(timeout)
            conn.sendall(b'! U1 getvar "device.product_name"\r\n')
            model = conn.recv(2048).decode('ascii','replace').strip('"\r\n ')
            if not ZEBRA.search(model):
                return None
            dpi = 300
            conn.sendall(b'! U1 getvar "head.resolution.in_dpi"\r\n')
            try:
                number = int(conn.recv(128).strip(b'"\r\n '))
                if number in (203,300,600):
                    dpi = number
            except (ValueError,OSError):
                pass
            return dict(address=address,port=port,model=model[:100],dpi=dpi,verified=True,source='Zebra read-only query')
    except OSError:
        return None

def unescape(value):
    return re.sub(r'\\(\d{3})',lambda m:chr(int(m[1])),value)

def parse_mdns(output):
    candidates = []
    for line in output.splitlines():
        fields = line.split(';',9)
        if len(fields) != 10 or fields[0] != '=' or fields[2] != 'IPv4':
            continue
        description = unescape(fields[3] + ' ' + fields[9])
        if 'application/vnd.lprint-test' in description:
            continue  # Our IPP bridge is not a physical printer.
        if not ZEBRA.search(description):
            continue
        if fields[4] != '_pdl-datastream._tcp':
            # IPP advertisements supply a hint, but raw ZPL must use port 9100.
            port = 9100
        else:
            port = int(fields[8])
        candidates.append(dict(address=fields[7],port=port,model=unescape(fields[3])[:100],verified=False,source='Bonjour hint'))
    return candidates

def discover(subnet=None):
    found, warnings = {}, []
    for service in ('_pdl-datastream._tcp','_printer._tcp','_ipp._tcp'):
        try:
            r = subprocess.run(['avahi-browse','-prt',service],capture_output=True,text=True,timeout=5)
            if r.returncode:
                warnings.append('Bonjour discovery is unavailable; use manual IP or a local subnet scan.')
            for p in parse_mdns(r.stdout):
                key=(p['address'],p['port'])
                found[key]=identify(*key) or p
        except (OSError, subprocess.TimeoutExpired):
            warnings.append('Bonjour discovery timed out; manual IP remains available.')
    if subnet:
        hosts = scan_hosts(subnet)
        with ThreadPoolExecutor(max_workers=24) as pool:
            for p in pool.map(identify,hosts):
                if p:
                    found[(p['address'],p['port'])]=p
    return list(found.values()), sorted(set(warnings))

def scan_hosts(subnet):
    try:
        net=ipaddress.ip_network(subnet,strict=False)
    except ValueError:
        raise ValueError('Enter a local IPv4 subnet, for example 192.168.50.0/24.')
    private=(ipaddress.ip_network('10.0.0.0/8'),ipaddress.ip_network('172.16.0.0/12'),ipaddress.ip_network('192.168.0.0/16'))
    if net.version != 4 or net.num_addresses > 256 or not any(net.subnet_of(n) for n in private):
        raise ValueError('Scan a private IPv4 subnet of /24 or smaller (256 addresses maximum).')
    return [str(ip) for ip in net.hosts()]
