# Zebra Printer Manager

## Open and configure

1. Start the app and enable Start on boot and Show in sidebar.
2. Open Web UI, or Zebra Printers in the Home Assistant sidebar.
3. Edit the initial Zebra ZD411 entry, find a Bonjour printer, scan a local subnet,
   or add a printer by IP. Defaults match 192.168.50.110:9100, 300 DPI, 54 × 70 mm
   gap labels and direct thermal.
4. Print one test label, inspect its physical dimensions and alignment, then use
   the standard iPad Print dialog and select the card's AirPrint name.

Many Zebra setups do not advertise Bonjour. Manual IP is always supported. Subnet
scanning is optional and read-only, private IPv4 /24 or smaller. Unconfirmed
Bonjour hints are labelled. Discovery does not automatically add or print to a
printer.

Choose gap for die-cut gap labels, black mark for marked stock, continuous for a
continuous roll, and the resolution of the actual printhead. Ribbon mode is only
for thermal-transfer hardware using ribbon. Settings cannot change the printer's
physical capabilities. Calibrate the roll using the printer's normal controls.
The configured queue ID is its stable AirPrint name; a friendly display name can
be edited without changing that ID.

## Status and tests

TCP reachable means a connection succeeded; it does not prove a label printed.
Reported idle/printing/stopped state and reasons come from LPrint, polled about
every 15 seconds. Refresh status is available. Test label submits a PNG through
the LPrint queue; inspect the result before repeating. Large tests are limited
to 16 megapixels. Diagnostics shows recent logs and downloads a JSON report,
which may contain LAN addresses and queue names but not label images.

When jobs are queued, **Cancel queued jobs** is available on the printer card.
Check whether a label already printed before cancelling or resubmitting.

Changes pause the print service briefly. Active or held jobs block configuration
changes. Let jobs finish before editing or updating. A failed apply restores the
previous queue state. Remove printer removes its queue/history. Up to 16 queues
are supported; do not add aliases that duplicate one physical printer accidentally.

## Persistence and updates

Keep the same repository URL/branch and slug when upgrading from LPrint 0.1.0.
Update through Home Assistant; existing queue settings migrate, and the old state
is backed up internally as pre-manager-lprint.conf. All manager settings, queues,
spool and rotating logs live in the app's /data and survive updates and restarts.
Include this app in Home Assistant backups. Changing repository identity creates
a different app instance and does not automatically copy its data.

The Configuration tab's printer_ip, printer_port and thermal_transfer values are
initialization/migration defaults, not the active per-printer settings. After
setup use this interface. ipp_port (default 8631) and log_level remain global;
restart after changing them. Do not edit raw LPrint state or configure CUPS.

## Access and networking

Home Assistant Ingress handles management authentication. Show in sidebar is for
administrators. The management endpoint rejects direct LAN requests; it uses a
Supervisor-selected port. Native LPrint web pages are disabled.

The separate AirPrint IPP service is on TCP 8631. iPads need to reach that port and
exchange multicast UDP 5353 with Home Assistant. Home Assistant needs outbound
TCP 9100 to each printer. Host networking enables discovery. Private D-Bus/Avahi
stay inside the app; A-only advertisement avoids competing for the host's reverse
mDNS record. No cupsd, TCP 631 listener or inbound raw-print listener is started.
If the same printer is advertised by another AirPrint bridge, stop that duplicate
queue before testing; unrelated printers can remain running.

A reachable interface alone does not prove multicast discovery. Check Wi-Fi client
isolation and VLAN rules. Multiple-network setups, physical printer faults and
real HAOS service coexistence still require on-site testing.

## iPads and IDEXX Neo

This is a software-tested experimental release. Real Home Assistant Green/HAOS
18.3 installation, iPad discovery, physical Zebra printing and IDEXX Neo have
not been verified. Test Neo's actual Print flow with one correctly sized label;
check page size, scaling, orientation and barcode readability. LPrint accepts
Apple/PWG Raster and images, not direct PDF. iOS/application rendering is part
of the remaining physical acceptance test.

The repository README, TESTING.md and PUBLISHING.md contain the complete evidence,
limitations, publishing instructions and sources. No HACS integration is needed:
HACS alone cannot install the print server.
