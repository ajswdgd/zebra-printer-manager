# 0.2.1

- Bound private D-Bus/Avahi readiness by wall-clock deadlines and explicit D-Bus/subprocess timeouts; detect child exits before proceeding. A stale socket is no longer treated as proof of readiness.
- Retain the existing three-attempt LPrint startup recovery. This does not prove the previously reported ARM64-emulation Avahi client assertion is fixed.
- Configure the repository and add-on URL for ajswdgd/zebra-printer-manager; preserve lprint_zebra identity, printing backend, manager configuration and all regression suites.
- No physical Green, Zebra or iPad compatibility claim; consult VALIDATION-0.2.1.md.

# 0.2.0

- Upgrade the existing LPrint add-on to Zebra Printer Manager, retaining its slug.
- Add a Home Assistant Ingress UI and admin sidebar entry.
- Add read-only Bonjour/SGD discovery, bounded optional subnet scan, manual setup,
  multiple queues, settings, monitoring, PNG test labels and diagnostics.
- Migrate original queue settings and preserve persistent LPrint state/history.
- Apply label settings through real ready/default IPP collections; safely update
  driver/transport fields while LPrint is stopped. Refuse changes with queued jobs.
- Preserve and extend the PNG, Apple Raster and PWG Raster regression tests.
- Actual HAOS/iPad/Zebra and IDEXX Neo verification remains outstanding.

# 0.1.0

Initial Zebra ZD411 300 DPI network add-on, persistent LPrint queue/spool and
explicit 54 × 70 mm media. Fixed upstream 2-inch selection, gap sensing and IPP
language attributes. Software tested; physical acceptance remained outstanding.
