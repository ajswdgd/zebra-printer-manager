# Upstream source

`lprint-1.3.1.tar.gz` is `git archive --format=tar.gz --prefix=lprint/ v1.3.1`
from https://github.com/michaelrsweet/lprint, commit
`a34bfb9e41af200dc48b4714ba8c720770c17531`.

SHA256: `f28c21bdd55e211ace6f908d938edb59d1ae6d3ef53b7485650779dcb0cb1d4a`.

Original Apache-2.0 LICENSE and NOTICE are preserved both here and in the archive.
The add-on wrapper is MIT licensed. Debian packages retain their own licenses in
`/usr/share/doc` in the image. LPrint is by Michael R Sweet; this is an independent
add-on, not an official Home Assistant, Zebra, Apple, or LPrint product.

The Dockerfile modifies this pinned source before building:

1. Fix `strncmp(..., "zpl_2inch-", 16)` to compare the actual 10-byte prefix.
2. Add `custom_54x70mm_54x70mm` to the 2-inch driver's supported media and extend
   its maximum custom width to 56 mm, for the ZD411 300 DPI printhead. Do not use
   this extended width for a narrower physical printer.
3. Treat IPP `gap` tracking like `web`, emitting Zebra `^MNY`, not `^MNM` (black
   mark). The upstream driver otherwise maps `gap` to black-mark sensing.
4. Omit LPrint's translated string-resource registrations. PAPPL 1.3.1 adds
   `printer-strings-languages-supported` to persistent printer attributes on each
   request, accumulating duplicate attributes and making repeated IPP validation
   fail. With no translated resources that faulty path adds nothing; the UI uses
   English. This avoids maintaining a fork of the PAPPL shared library.

The wrapper also internally restarts LPrint once after initial queue creation.
PAPPL 1.3.1 stores the initial `printer-id` attribute as zero and does not
initialize the new queue's DNS-SD name in the live add path; loading the saved
queue initializes both. This is automatic and needs no user restart.

## Manager 0.2.0 changes

The printing system remains the same release/build and the original raster
regressions are retained. `manager-media.inc` is inserted into the existing driver
callback before PAPPL builds its attributes. It reads a maximum of 16 bounded
URI/media entries from the manager-generated `/data/media/driver-map.txt` and adds
the selected custom stock to the supported and loaded media. This is necessary:
changing only the ready-media UI does not reliably update supported IPP media.
The automatic custom-media matcher is disabled in managed mode so status polling
does not replace explicit dimensions based on an approximate hardware length.
The generic 4-inch range is extended to the manager's 104 mm bound; users must
still choose settings their physical printer supports.

Native LPrint web pages are disabled in managed mode. The underlying IPP service,
raster renderer, ZPL driver and raw TCP transport remain LPrint/PAPPL. The manager
sets default **and** ready collections through IPP because the ready-media setter
can otherwise overwrite sensing defaults.

PAPPL 1.3.1's `lprint modify -m/-v` does not update the driver/transport. The manager
therefore stops LPrint, surgically updates those two serialized queue header
fields, and reloads it, preserving queue IDs, UUIDs and completed jobs. No files
are edited while LPrint is running. Invalid apply operations restore the previous
state. A one-time queue reload retains the earlier first-install DNS-SD fix.
