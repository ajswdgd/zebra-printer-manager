# Zebra Printer Manager

Manage network Zebra ZPL label printers inside Home Assistant: discovery or manual
IP setup, DPI/label/sensing settings, status, a test-label button and diagnostics.
LPrint provides IPP/AirPrint for iPads; all configuration is persistent.

Install, Start, enable Show in sidebar, and select Open Web UI. The initial entry
is a Zebra ZD411 at 192.168.50.110:9100, 300 DPI, 54 × 70 mm gap labels.
No SSH, external print server, HACS or CUPS administration is required.

Software tests are documented in the repository. Real Home Assistant Green,
HAOS 18.3, Zebra output and iPad / IDEXX Neo printing remain acceptance tests;
this release is experimental until verified there.
