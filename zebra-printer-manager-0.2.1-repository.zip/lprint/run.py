#!/usr/bin/env python3
"""Zebra Printer Manager app entry point; keeps LPrint as the printing service."""
import logging
import signal
import threading
from manager.runtime import Runtime
from manager.web import Server

runtime=None
server=None
stopping=threading.Event()
def stop(signum,frame):stopping.set()

if __name__=='__main__':
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    result=0
    try:
        runtime=Runtime();runtime.start()
        server=Server(runtime,runtime.ingress_port())
        threading.Thread(target=server.serve_forever,daemon=True).start()
        logging.getLogger('zebra').info('Zebra Printer Manager ready through Home Assistant Ingress (port %s)',server.server_port)
        while not stopping.wait(.25):runtime.check()
    except Exception:
        logging.getLogger('zebra').exception('Startup/service failure');result=1
    finally:
        if server:server.shutdown();server.server_close()
        if runtime:runtime.close()
    raise SystemExit(result)
