# Zebra Printer Manager 0.2.1 validation

Recorded 2026-10-27. This candidate was prepared from the user's complete
`zebra-printer-manager-0.2.0.zip`, not rebuilt as a substitute project. The
original archive, source licenses, tests and historical evidence were retained.
The target repository is `ajswdgd/zebra-printer-manager`; no public repository or
GitHub Actions run was created by this workspace because GitHub authentication
is invalid.

## What changed

Version **0.2.1** contains a runtime startup patch, so it has a new patch version
rather than silently replacing 0.2.0. Private D-Bus readiness now requires a
successful round trip, and Avahi state/hostname requests have timeouts and child
exit checks. The existing three LPrint startup attempts are retained. See
[AVAHI-INVESTIGATION.md](AVAHI-INVESTIGATION.md) for the distinction between this
bounded failure handling and the unresolved cause of the earlier emulator
assertion.

The original Dockerfile, vendored LPrint source, print/media backend patches,
manager UI JavaScript/CSS, discovery/validation/printing modules and v0.1
migration fixtures are unchanged. Existing test changes are limited to the new
expected version and optional QEMU support in the migration harness. New tests
cover readiness failures and distribution packaging. Repository metadata,
publication instructions and CI were updated. `SETUP-WORKFLOW.txt` was retained
as `SETUP-WORKFLOW-0.2.0.txt` for history; do not run that old embedded snapshot.

Add-on identity remains folder **`lprint/`**, slug **`lprint_zebra`**, persistent
**`/data`**, dynamic Ingress and architectures **aarch64/amd64**. The repository
uses Supervisor source builds, with no prebuilt registry image claim. The pinned
LPrint 1.3.1 archive SHA256 remains
`f28c21bdd55e211ace6f908d938edb59d1ae6d3ef53b7485650779dcb0cb1d4a`.

## Executed checks

| Check | Result |
| --- | --- |
| Unit tests | **18 passed**: six retained manager checks, eight startup checks and four packaging checks. |
| Native AMD64 production image | Built successfully from the original Dockerfile and patched manager. |
| ARM64 production image | Built successfully with BuildKit/QEMU on an AMD64 host. This is emulation, not native Green execution. |
| Original print regression, both images | Passed repeated IPP queries, AirPrint subtype/TXT checks, PNG/URF/PWG-to-captured-TCP-ZPL, container replacement and darkness persistence. |
| Original manager regression, both images | Passed synthetic Bonjour discovery plus Zebra identity confirmation, multiple printers, dimensions/DPI/sensing settings, actual destination changes, held-job protection, diagnostics, offline handling, edits/removal and restart persistence. |
| Original v0.1 migration, both images | Passed queue/address, 300 DPI, 54 × 70 mm stock, darkness 61, system UUID, completed jobs and retained backup checks. |
| Production-container D-Bus fault | Hung readiness client failed closed: **12.89 s AMD64**, **17.35 s emulated ARM64**, including test/container overhead. Neither logged readiness. |
| Production-container Avahi fault | Exited Avahi child failed closed: **3.47 s AMD64**, **6.34 s emulated ARM64**. Neither logged readiness. |
| Existing browser regression | Passed in Chromium desktop/mobile layouts through a simulated prefix-stripping HA Ingress proxy, including assets/API, add/edit/remove and diagnostics; no JavaScript exceptions. |
| Offline packaging | Passed identity, architecture, options/schema matching, Ingress settings, version consistency, required source/assets and pinned source hash checks. |

Captured runtime artifacts and result logs are in
[`evidence-0.2.1/`](evidence-0.2.1/), separated into native AMD64,
ARM64 emulation and browser results. All printer endpoints used for these checks
were simulators; captured ZPL is not physical printer output. No clinic camera,
Abode alarm or physical printer action was invoked.

Local Docker image IDs, for audit rather than registry installation:

- AMD64: `sha256:2570e198a676dd85deb4929d3bd069b70c74853842ccd6dcfb32a0601e1500b4`
- ARM64: `sha256:fb623776abbbd287dd905bc175e12753294ada7f749a2effa0cc4415fd8201e6`

## Publication and remaining acceptance

The source ZIP and matching small importer workflow are a browser-only handover.
The importer is checksum-pinned, checks the public repository identity, preserves
the source tree/tests/workflows and refuses to overwrite an existing application.
The common importer guard tests passed in the companion Amcrest packaging suite;
actual GitHub import, token permissions and retained CI must still run in the
public repositories. See [IPAD-PUBLISHING.md](IPAD-PUBLISHING.md).

Before clinic use, complete actual Supervisor repository installation/update and
Ingress checks on Home Assistant Green/HAOS 18.3; cold starts and host reboots on
native ARM64; physical printer calibration/output and recovery; Safari/iPad
AirPrint, clinic multicast/VLAN behavior and IDEXX Neo acceptance. These checks
cannot be inferred from a container build, a simulated proxy or emulation. The
previous Avahi assertion was not reproduced in these successful ARM64 runs; its
root cause and freedom from recurrence are unproven. The retained historical
[TESTING.md](TESTING.md) includes the physical acceptance checklist.

Back up through HA before updating. Preserving slug/folder and the same repository
URL keeps an existing add-on instance; a new repository does not automatically
transfer `/data` from a differently hosted/local add-on. Do not delete the old
instance when testing that move.
