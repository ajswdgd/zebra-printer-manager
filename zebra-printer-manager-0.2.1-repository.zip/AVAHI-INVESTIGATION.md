# Avahi startup investigation — 0.2.1

Investigation date: 2026-10-27. The 0.2.1 change makes private D-Bus and Avahi
startup checks time limited and reports failures explicitly. It does not establish
or fix the cause of the previously reported ARM64 emulator assertion.

## What the supplied project establishes

The original [0.2.0 test report](TESTING.md) records one ARM64 emulator run in
which LPrint hit an assertion in Avahi's D-Bus client glue during startup. The
report already describes three bounded LPrint startup attempts as recovery from
that observation. Those retries are retained in 0.2.1; they are not a new fix.

The supplied final runtime logs show successful starts. They do not contain the
failing assertion stack trace, so they cannot establish its root cause or prove
that an upstream race has been eliminated. Physical Home Assistant Green startup
and long-running stability were not tested in that earlier workspace either.

Inspection identified a separate reliability problem in the wrapper: D-Bus
readiness depended on a socket file existing, while Avahi state and hostname
requests had no subprocess timeout. A socket can exist without a responsive bus,
and a stuck client could prevent the apparent retry loop from progressing.

## Changes made

[The readiness helpers](lprint/manager/startup.py) and
[runtime startup](lprint/manager/runtime.py) now:

- Require a successful `org.freedesktop.DBus.ListNames` round trip on the private
  bus, within a 10-second readiness budget.
- Require Avahi's exact `RUNNING` state (`int32 2`), within a separate 15-second
  readiness budget. A different state, including `20`, does not count as ready.
- Limit each D-Bus reply wait to at most one second and each client subprocess to
  at most two seconds, further limited by the remaining readiness budget.
- Stop with an explicit startup error if either relevant child exits, the
  readiness client cannot run, or a readiness deadline expires.
- Limit Avahi hostname lookup to two seconds and reject an unsuccessful or
  malformed response. D-Bus machine-ID setup also has a five-second timeout.

The existing three LPrint startup attempts remain separate from those readiness
budgets. This is not a promise that the entire application will always finish
starting within 25 seconds: LPrint startup, queue setup and configuration reloads
have their own work and limits. Runtime child failures still stop the application
with an error rather than reporting it as healthy.

The vendored LPrint backend, printing patches, private D-Bus design, A-only mDNS
address publication and add-on identity are retained. This change does not require
access to the host's D-Bus or new host privileges.

## Verified results for this change

The following results were obtained in native AMD64 Linux containers, with
simulated Zebra endpoints and a simulated Ingress proxy where applicable. They
are software verification, not physical Home Assistant, Green, printer or iPad
acceptance. The ARM64 image also built and passed the retained print/API/migration
suites under BuildKit/QEMU, plus the same fault checks (17.35 seconds for a hung
D-Bus client and 6.34 seconds for an exited Avahi child). Those successful runs
did not reproduce the original assertion. Consult
[the release validation report](VALIDATION-0.2.1.md) for architecture results.

| Check | Observed result |
| --- | --- |
| Unit and packaging suite | All 18 tests passed: six retained manager checks, eight readiness checks and four packaging checks. |
| Hung D-Bus client | A deliberately hung `dbus-send` caused an explicit startup failure in 12.89 seconds of overall test time. The application did not log a ready/print-ready claim. |
| Avahi process exit | A stub Avahi process exiting with status 7 caused an explicit startup failure in 3.47 seconds of overall test time. No ready/print-ready claim was logged. |
| Printing regression | Repeated IPP requests, AirPrint subtype/TXT data, PNG/URF/PWG delivery to captured TCP ZPL, container replacement and darkness persistence passed. |
| Manager regression | Live synthetic Bonjour discovery with Zebra identity confirmation; multiple printers; DPI, stock and sensing changes; actual transport changes; held-job protection; offline handling; diagnostics; removal and persistence passed. |
| Migration | The real supplied v0.1 state retained its queue, address, 300 DPI, 54 × 70 mm stock, darkness 61, system UUID and completed jobs, with a backup retained. |
| Browser regression | Ingress-prefix assets/API, desktop/mobile layouts, add/edit/remove and diagnostics passed in Chromium without JavaScript exceptions, through a simulated proxy. |

The fault-test elapsed times include container startup and test overhead; the
D-Bus readiness budget itself is 10 seconds. The integration fault tests replace
only the relevant executable with a controlled stub and run the production
container. They verify bounded failure handling; they do not reproduce the
original upstream assertion.

Raw service logs and runtime evidence are in
[`evidence-0.2.1/amd64/`](evidence-0.2.1/amd64/), including
[`startup/dbus-hang.log`](evidence-0.2.1/amd64/startup/dbus-hang.log) and
[`startup/avahi-exit.log`](evidence-0.2.1/amd64/startup/avahi-exit.log).
Browser artifacts are in [`evidence-0.2.1/browser/`](evidence-0.2.1/browser/).
The original evidence remains preserved as historical evidence.

## Log interpretation and remaining checks

Some successful supplied runs contain warnings about the D-Bus file-descriptor
limit, missing NSS mDNS support or no Avahi service files. Their presence alone
did not indicate the reported fatal assertion: those runs subsequently started
and passed software checks. Diagnose a failure from its actual error and
surrounding logs rather than treating those warnings as a proven root cause.

On the actual Home Assistant Green, use the add-on's **Logs** page to confirm a
successful start, then repeat after an add-on restart and a Home Assistant host
reboot. Save logs if an assertion, repeated failed LPrint attempts, a readiness
timeout or a service exit occurs. Confirm printer discovery and printing from the
actual iPad, including coexistence with existing mDNS services and the clinic's
network topology. No SSH or Linux commands are required for these acceptance
steps.

Native ARM64 behavior, actual Supervisor installation/update and Ingress,
physical printer output, iPad AirPrint and recovery under real hardware/network
faults require their own recorded results. A successful software run or recovery
retry does not prove that the original assertion cannot recur.
