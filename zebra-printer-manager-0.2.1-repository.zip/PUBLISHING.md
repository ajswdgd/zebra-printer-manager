# Publish Zebra Printer Manager as a Home Assistant add-on repository

Target: **https://github.com/ajswdgd/zebra-printer-manager**. Repository metadata is configured for ajswdgd, but this workspace cannot publish it because GitHub authentication is invalid. No live repository, image registry publication or Supervisor installation is claimed.

Use **[IPAD-PUBLISHING.md](IPAD-PUBLISHING.md)** for the browser-only route: create the public repository, upload the single reviewed `zebra-printer-manager-0.2.1-repository.zip`, and paste the supplied small `setup-zebra-publication.yml.txt` into GitHub's web editor. A scoped secret lets GitHub Actions unpack the ZIP including its retained workflows; no SSH, Linux command or source-tree copying is needed. The import checks its exact checksum and refuses to overwrite existing application source. Wait for subsequent native AMD64/ARM64 tests to pass before using the add-on repository.

The previous 0.2.0 embedded bootstrap is preserved only as `SETUP-WORKFLOW-0.2.0.txt` and the original generator remains historical tooling. Do not use that older snapshot to publish this patch. The uploaded original 0.2.0 archive is retained separately for audit.

## Repository layout

At the GitHub root: `repository.yaml`, README.md, LICENSE, PUBLISHING.md, tests/scripts and `.github/workflows/test.yaml`. The `lprint/` folder contains `config.yaml`, Dockerfile, manager, Ingress UI, translations, source license/notice, and the vendored LPrint archive. Do not add a wrapper directory around them.

The required metadata retains **slug `lprint_zebra`**, **folder `lprint/`**, native **aarch64/amd64**, dynamic Ingress and persistent `/data`. Runtime version is **0.2.1** for bounded startup readiness; original 0.2.0 print/backend/media and queue migration behavior remain. The full vendored source SHA256 is validated before builds. Manifests are checked by `scripts/validate_repository.py`; actual Supervisor installation still needs acceptance.

This repository uses **Supervisor source builds**. There is no `image:` registry reference and no prebuilt-image claim: Green chooses ARM64 from the Debian multi-platform base and automatically compiles the pinned LPrint source in its container. This can take several minutes. Users only tap Install/Update; they do not run commands or provide an external computer. Network access to Docker Hub and Debian repositories is required during that build.

## Installation and upgrades through Home Assistant

Once the actual repository is published and its native CI succeeds:

1. Add `https://github.com/ajswdgd/zebra-printer-manager` in **Settings → Add-ons → Add-on Store → ⋮ → Repositories** (Apps/App Store on newer UI).
2. Select Zebra Printer Manager, Install, Start, and Open Web UI. Configure printers in its admin Ingress page, not through filesystem edits.
3. Verify one physical test label before regular printing; software capture does not prove scale, calibration or print quality.
4. For updates, take a backup including this add-on, ensure no jobs are printing/held, refresh the add-on store, and tap Update. Retain the same URL/branch, folder and slug. This keeps the add-on's repository identity and `/data`.
5. Existing v0.1 state migrates automatically within that same add-on instance; legacy state is additionally backed up internally. A differently hosted or local add-on has a different Supervisor identifier and does not automatically transfer its data to this new repository. This release does not add a cross-repository transfer feature. Use a verified HA backup/restore procedure for such a move; do not delete the original instance or hand-edit `/data`.
6. Roll back using Home Assistant's backup/restore UI. Do not rerun a stale bootstrap to overwrite newer source.

HACS cannot install this printing server. Amcrest is a separate HACS integration with its own repository. Hardware and actual HAOS/iPad validation remain separate from packaging and native/emulated container tests.

References: [Home Assistant repositories](https://contributors.home-assistant.io/apps/guides/repository/), [Ingress](https://contributors.home-assistant.io/apps/guides/ingress/), [configuration reference](https://contributors.home-assistant.io/apps/reference/configuration/).
